import streamlit as st
from utils.openai_helper import generate_response
from utils.multi_model_helper import multi_model
from utils.doc_generator import generate_docx
import time

st.set_page_config(
    page_title="AI Multi-Model Chat & Doc Generator",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Modern CSS styling with gradients, animations, and interactive elements
st.markdown(
    """
    <style>
        /* Import Google Fonts */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        /* Main background with gradient */
        .stApp {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', sans-serif;
        }
        
        /* Container styling */
        .block-container {
            padding: 2rem 3rem 4rem;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
            margin: 1rem auto;
            max-width: 1200px;
        }
        
        /* Header styling */
        .main-header {
            text-align: center;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .sub-header {
            text-align: center;
            color: #6b7280;
            font-size: 1.2rem;
            margin-bottom: 2rem;
            font-weight: 400;
        }
        
        /* Tab styling */
        .stTabs [data-baseweb="tab-list"] {
            gap: 24px;
            background-color: #f8fafc;
            border-radius: 15px;
            padding: 8px;
            margin-bottom: 2rem;
        }
        
        .stTabs [data-baseweb="tab"] {
            height: 60px;
            padding: 0px 24px;
            background-color: transparent;
            border-radius: 12px;
            color: #64748b;
            font-weight: 500;
            font-size: 16px;
            transition: all 0.3s ease;
            border: none;
        }
        
        .stTabs [aria-selected="true"] {
            background: linear-gradient(135deg, #667eea, #764ba2) !important;
            color: white !important;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transform: translateY(-2px);
        }
        
        /* Input styling */
        .stTextInput > div > div > input {
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 15px 20px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .stTextInput > div > div > input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-1px);
        }
        
        .stTextArea > div > div > textarea {
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 15px 20px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            min-height: 120px;
        }
        
        .stTextArea > div > div > textarea:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        /* Button styling */
        .stButton > button {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            text-transform: none;
        }
        
        .stButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
            background: linear-gradient(135deg, #5a67d8, #6b46c1);
        }
        
        .stDownloadButton > button {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }
        
        .stDownloadButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
        }
        
        /* Chat message styling */
        .chat-message {
            padding: 15px 20px;
            margin: 10px 0;
            border-radius: 15px;
            animation: fadeInUp 0.5s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .user-message {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            margin-left: 20%;
            border-bottom-right-radius: 5px;
        }
        
        .ai-message {
            background: linear-gradient(145deg, #f8fafc, #e2e8f0);
            color: #374151;
            margin-right: 20%;
            border-bottom-left-radius: 5px;
        }
        
        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Status indicators */
        .status-success {
            color: #10b981;
            font-weight: 600;
        }
        
        .status-processing {
            color: #f59e0b;
            font-weight: 600;
        }
        
        .status-error {
            color: #ef4444;
            font-weight: 600;
        }
        
        /* Model status indicators */
        .model-status {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
        }
        
        .model-online {
            background-color: #d1fae5;
            color: #065f46;
        }
        
        .model-offline {
            background-color: #fee2e2;
            color: #991b1b;
        }
        
        /* Sidebar styling and visibility */
        .css-1d391kg {
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        
        /* Ensure sidebar is visible */
        .css-1lcbmhc {
            display: block !important;
        }
        
        /* Sidebar content styling */
        .css-17eq0hr {
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        /* Sidebar text color */
        .css-1d391kg .css-1v0mbdj {
            color: white;
        }
        
        /* Hide Streamlit branding */
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        header {visibility: hidden;}
    </style>
""",
    unsafe_allow_html=True,
)

# Modern header with animations
st.markdown('<h1 class="main-header">🤖 AI Multi-Model Chat & 📄 Document Generator</h1>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">✨ Supporting OpenAI • Ollama • HuggingFace • Free Open Source Models</p>', unsafe_allow_html=True)

# Add sidebar indicator if not visible
col1, col2, col3 = st.columns([1, 2, 1])

with col2:
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px; border-radius: 12px; margin-bottom: 20px; text-align: center; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);">
        <h4 style="margin: 0; color: white;">👈 Configure Models in Sidebar</h4>
        <p style="margin: 5px 0 0 0; opacity: 0.9;">Choose your AI provider (OpenAI, Ollama, HuggingFace) from the left panel</p>
        <small>💡 If sidebar is not visible, look for the ">" arrow at the top-left or press Ctrl+Shift+A</small>
    </div>
    """, unsafe_allow_html=True)

# Current model display
if "current_provider" not in st.session_state:
    st.session_state.current_provider = "ollama"
if "current_model" not in st.session_state:
    st.session_state.current_model = "llama2"

# Model status indicator in main area
col1, col2, col3 = st.columns(3)
with col1:
    st.info(f"🤖 **Provider:** {st.session_state.current_provider.title()}")
with col2:
    st.info(f"📡 **Model:** {st.session_state.current_model}")
with col3:
    provider_status = multi_model.check_provider_status(st.session_state.current_provider)
    if provider_status:
        st.success("✅ **Status:** Online")
    else:
        st.error("❌ **Status:** Offline")

# JavaScript to ensure sidebar is expanded
st.markdown("""
<script>
// Force sidebar to be expanded
setTimeout(function() {
    const sidebar = parent.document.querySelector('[data-testid="stSidebar"]');
    if (sidebar) {
        sidebar.style.display = 'block';
        sidebar.style.width = '21rem';
    }
}, 1000);
</script>
""", unsafe_allow_html=True)

# Initialize session state
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "docs_generated" not in st.session_state:
    st.session_state.docs_generated = 0

# Sidebar with model selection and configuration
with st.sidebar:
    st.markdown("### 🎯 Model Configuration")
    
    # Model provider selection
    provider = st.selectbox(
        "🔧 AI Provider",
        ["ollama", "huggingface", "openai"],
        index=["ollama", "huggingface", "openai"].index(st.session_state.current_provider),
        help="Choose your AI model provider"
    )
    
    # Update session state when provider changes
    if provider != st.session_state.current_provider:
        st.session_state.current_provider = provider
        st.rerun()
    
    # Get available models for selected provider
    available_models = multi_model.get_available_models()
    
    if provider == "ollama":
        st.markdown("#### 🦙 Ollama (Local & Free)")
        models = list(multi_model.models["ollama"].keys())
        try:
            default_index = models.index(st.session_state.current_model) if st.session_state.current_model in models else 0
        except:
            default_index = 0
        model = st.selectbox("Model", models, index=default_index, help="Local Ollama models")
        
        # Update session state when model changes
        if model != st.session_state.current_model:
            st.session_state.current_model = model
            st.rerun()
        
        # Check Ollama status
        ollama_status = multi_model.check_provider_status("ollama")
        if ollama_status:
            st.markdown('<span class="model-status model-online">🟢 Online</span>', unsafe_allow_html=True)
            st.success("✅ Ollama is running!")
        else:
            st.markdown('<span class="model-status model-offline">🔴 Offline</span>', unsafe_allow_html=True)
            st.warning("⚠️ Ollama not detected")
            with st.expander("🛠️ Setup Ollama (Click to expand)"):
                st.markdown("""
                **Quick Setup:**
                1. Download from [ollama.ai](https://ollama.ai)
                2. Install and start Ollama
                3. Open terminal/command prompt
                4. Run: `ollama pull llama2`
                5. Refresh this page
                
                **Popular Models:**
                - `ollama pull llama2` (General purpose)
                - `ollama pull codellama` (Code generation)
                - `ollama pull mistral` (Fast & efficient)
                """)
        
        api_key = None
        
    elif provider == "huggingface":
        st.markdown("#### 🤗 HuggingFace (Free)")
        models = list(multi_model.models["huggingface"].keys())
        model = st.selectbox("Model", models, help="Free HuggingFace models")
        
        st.markdown('<span class="model-status model-online">🟢 Available</span>', unsafe_allow_html=True)
        
        api_key = st.text_input(
            "🔑 HF Token (Optional)", 
            type="password",
            help="Optional: For higher rate limits"
        )
        
    else:  # openai
        st.markdown("#### 🤖 OpenAI (Paid)")
        models = list(multi_model.models["openai"].keys())
        model = st.selectbox("Model", models, help="OpenAI models")
        
        api_key = st.text_input(
            "🔑 OpenAI API Key", 
            type="password",
            help="Required for OpenAI models"
        )
    
    st.markdown("---")
    st.markdown("### 🚀 Features")
    st.markdown("""
    **🗨️ Multi-Model Chat**
    - OpenAI GPT models
    - Free Ollama models (local)
    - HuggingFace models (free)
    
    **📄 Document Generation**
    - AI-powered content creation
    - Professional Word documents
    - Multiple model support
    
    **⚡ Technology Stack**
    - Multiple AI providers
    - Streamlit interface
    - Python-docx engine
    """)
    
    st.markdown("---")
    st.markdown("### 📊 Session Stats")
    
    if st.session_state.chat_history:
        chat_count = len([msg for msg in st.session_state.chat_history if msg[0] == "You"])
        st.metric("Messages Sent", chat_count)
    
    st.metric("Documents Created", st.session_state.docs_generated)

# Main tabs
tab1, tab2 = st.tabs(["💬 Multi-Model Chat", "📄 Document Creator"])

with tab1:
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown(f"### 🤖 AI Assistant ({provider.title()}: {model})")
        st.markdown("*Choose different AI models and compare their responses!*")
    
    with col2:
        if st.button("🗑️ Clear Chat", help="Clear conversation history"):
            st.session_state.chat_history = []
            st.rerun()

    # Chat input with enhanced styling
    user_input = st.text_input(
        "💭 What's on your mind?", 
        placeholder=f"Type your message here... (Using {provider.title()}: {model})",
        key="chat_input"
    )

    if user_input:
        # Add loading animation
        with st.spinner(f"🧠 {model} is thinking..."):
            try:
                # Use multi-model helper
                if provider == "openai" and not api_key:
                    st.error("❌ Please enter your OpenAI API key in the sidebar")
                else:
                    response = multi_model.generate_response(
                        user_input, 
                        provider, 
                        model, 
                        api_key=api_key, 
                        hf_token=api_key if provider == "huggingface" else None
                    )
                    
                    st.session_state.chat_history.append(("You", user_input))
                    st.session_state.chat_history.append(("AI", response))
                    st.rerun()
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")

    # Enhanced chat display
    if st.session_state.chat_history:
        st.markdown("### 💬 Conversation")
        
        # Create a container for chat messages
        chat_container = st.container()
        
        with chat_container:
            for i, (speaker, message) in enumerate(reversed(st.session_state.chat_history[-10:])):  # Show last 10 messages
                if speaker == "You":
                    st.markdown(f"""
                    <div class="chat-message user-message">
                        <strong>👤 You:</strong><br>{message}
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="chat-message ai-message">
                        <strong>🤖 {provider.title()} ({model}):</strong><br>{message}
                    </div>
                    """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div style="background: linear-gradient(145deg, #ffffff, #f8fafc); border-radius: 15px; padding: 25px; margin: 15px 0; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);">
            <h4>👋 Welcome to Multi-Model AI Chat!</h4>
            <p>You're currently using <strong>{provider.title()}</strong> with the <strong>{model}</strong> model.</p>
            <p>Start a conversation by typing a message above. Here are some ideas:</p>
            <ul>
                <li>🔬 Ask about science and technology</li>
                <li>💡 Get creative writing ideas</li>
                <li>🎯 Request help with problem-solving</li>
                <li>📚 Learn about any topic</li>
                <li>🤔 Compare responses from different models</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

with tab2:
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown(f"### 📝 AI Document Generator ({provider.title()})")
        st.markdown("*Transform your ideas into professional documents with multi-model AI assistance.*")
    
    with col2:
        st.metric("📄 Model", f"{provider.title()}", delta=model)
    
    # Document type selector
    doc_type = st.selectbox(
        "📋 Document Type",
        ["Business Letter", "Report", "Article", "Proposal", "Meeting Notes", "Creative Writing", "Technical Documentation", "Custom"],
        help="Choose the type of document you want to generate"
    )
    
    # Enhanced prompt input
    if doc_type == "Custom":
        prompt = st.text_area(
            "✍️ Enter your detailed instruction for document generation:",
            placeholder="Describe exactly what you want the AI to write. Be specific about tone, style, length, and content...",
            height=150,
            help="The more detailed your prompt, the better the output!"
        )
    else:
        prompt = st.text_area(
            f"✍️ Describe your {doc_type.lower()}:",
            placeholder=f"Provide details about the {doc_type.lower()} you want to create. Include key points, audience, tone, and any specific requirements...",
            height=150,
            help="Provide context and specific details for better results"
        )
    
    # Advanced options in expander
    with st.expander("⚙️ Advanced Options"):
        col1, col2 = st.columns(2)
        
        with col1:
            tone = st.selectbox("🎭 Tone", ["Professional", "Casual", "Formal", "Friendly", "Technical", "Creative"])
            length = st.selectbox("📏 Length", ["Short (1-2 paragraphs)", "Medium (3-5 paragraphs)", "Long (6+ paragraphs)"])
        
        with col2:
            audience = st.selectbox("👥 Target Audience", ["General", "Business", "Academic", "Technical", "Students", "Executives"])
            format_style = st.selectbox("📐 Format", ["Standard", "Structured", "Bullet Points", "Narrative"])
    
    # Enhanced generation section
    if st.button("🚀 Generate Document", use_container_width=True) and prompt:
        # Check requirements for different providers
        if provider == "openai" and not api_key:
            st.error("❌ Please enter your OpenAI API key in the sidebar")
        elif provider == "ollama" and not multi_model.check_provider_status("ollama"):
            st.error("❌ Ollama is not running. Please start Ollama first.")
        else:
            # Enhanced prompt with context
            enhanced_prompt = f"""
            Create a {doc_type.lower()} with the following specifications:
            
            Content Request: {prompt}
            
            Style Guidelines:
            - Tone: {tone}
            - Length: {length}
            - Target Audience: {audience}
            - Format: {format_style}
            
            Please ensure the document is well-structured, professional, and meets the specified requirements.
            """
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                status_text.markdown('<p class="status-processing">🔄 Initializing AI generation...</p>', unsafe_allow_html=True)
                progress_bar.progress(25)
                time.sleep(0.5)
                
                status_text.markdown(f'<p class="status-processing">🧠 {model} is crafting your document...</p>', unsafe_allow_html=True)
                progress_bar.progress(50)
                
                # Generate content using selected model
                output_text = multi_model.generate_response(
                    enhanced_prompt, 
                    provider, 
                    model, 
                    api_key=api_key, 
                    hf_token=api_key if provider == "huggingface" else None
                )
                progress_bar.progress(75)
                
                status_text.markdown('<p class="status-processing">📄 Creating Word document...</p>', unsafe_allow_html=True)
                docx_file = generate_docx(output_text, doc_title=f"{doc_type} - Generated by {provider.title()}")
                progress_bar.progress(100)
                
                status_text.markdown('<p class="status-success">✅ Document generated successfully!</p>', unsafe_allow_html=True)
                st.session_state.docs_generated += 1
                
                # Document preview
                with st.expander("👀 Preview Generated Content", expanded=True):
                    st.markdown(f"### 📖 Document Preview (Generated by {provider.title()} - {model})")
                    st.markdown(output_text)
                
                # Download section with enhanced styling
                col1, col2, col3 = st.columns([1, 2, 1])
                
                with col2:
                    with open(docx_file, "rb") as f:
                        st.download_button(
                            label="📥 Download DOCX File",
                            data=f,
                            file_name=f"generated_{doc_type.lower().replace(' ', '_')}_{provider}.docx",
                            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            use_container_width=True
                        )
                
                # Success metrics
                word_count = len(output_text.split())
                char_count = len(output_text)
                
                col1, col2, col3 = st.columns(3)
                col1.metric("📝 Words", word_count)
                col2.metric("🔤 Characters", char_count)
                col3.metric("📄 Pages (Est.)", max(1, word_count // 250))
                
            except Exception as e:
                status_text.markdown(f'<p class="status-error">❌ Error: {str(e)}</p>', unsafe_allow_html=True)
                progress_bar.empty()
    
    else:
        # Feature showcase when no prompt
        st.markdown(f"""
        <div style="background: linear-gradient(145deg, #ffffff, #f8fafc); border-radius: 15px; padding: 25px; margin: 15px 0; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);">
            <h4>🎯 Multi-Model Document Generation</h4>
            <p>Currently using <strong>{provider.title()}</strong> with <strong>{model}</strong> model.</p>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px;">
                <div>
                    <h5>📋 Document Types</h5>
                    <ul>
                        <li>Business Letters</li>
                        <li>Reports & Proposals</li>
                        <li>Articles & Content</li>
                        <li>Technical Documentation</li>
                    </ul>
                </div>
                <div>
                    <h5>⚡ Multi-Model Features</h5>
                    <ul>
                        <li>OpenAI GPT models</li>
                        <li>Free Ollama models</li>
                        <li>HuggingFace models</li>
                        <li>Professional formatting</li>
                    </ul>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
