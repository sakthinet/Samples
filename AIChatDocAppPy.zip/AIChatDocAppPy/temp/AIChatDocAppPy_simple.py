import streamlit as st
from utils.openai_helper import generate_response
from utils.multi_model_helper import multi_model
from utils.doc_generator import generate_docx
import time

st.set_page_config(
    page_title="AI Multi-Model Chat & Doc Generator",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Force sidebar to be visible with aggressive CSS
st.markdown("""
<style>
/* Import modern fonts */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

/* Main app layout */
.stApp {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* Sidebar styling with proper alignment */
.css-1d391kg, [data-testid="stSidebar"] {
    background: linear-gradient(180deg, #2d3748 0%, #4a5568 100%) !important;
    border-right: 3px solid #667eea !important;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1) !important;
}

/* Sidebar content */
.css-1d391kg .css-1v0mbdj {
    color: white !important;
}

/* Sidebar headers */
.css-1d391kg h1, .css-1d391kg h2, .css-1d391kg h3 {
    color: #e2e8f0 !important;
}

/* Sidebar text */
.css-1d391kg p, .css-1d391kg div {
    color: #cbd5e0 !important;
}

/* Custom hamburger menu */
.hamburger-menu {
    position: fixed;
    top: 1rem;
    left: 1rem;
    z-index: 1000;
    background: rgba(45, 55, 72, 0.9);
    border: none;
    border-radius: 8px;
    padding: 12px;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    transition: all 0.3s ease;
}

.hamburger-menu:hover {
    background: rgba(45, 55, 72, 1);
    transform: scale(1.05);
}

.hamburger-line {
    width: 20px;
    height: 2px;
    background-color: white;
    margin: 4px 0;
    transition: 0.3s;
    border-radius: 2px;
}

/* Main content container */
.block-container {
    background: rgba(255, 255, 255, 0.95) !important;
    border-radius: 20px !important;
    padding: 2rem 3rem !important;
    margin: 1rem 2rem 1rem 1rem !important;
    backdrop-filter: blur(20px) !important;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1) !important;
    border: 1px solid rgba(255, 255, 255, 0.2) !important;
}

/* Header styling */
.main-title {
    text-align: center;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.sub-title {
    text-align: center;
    color: #6b7280;
    font-size: 1.1rem;
    margin-bottom: 2rem;
    font-weight: 400;
}

/* Tab styling */
.stTabs [data-baseweb="tab-list"] {
    gap: 20px;
    background-color: #f8fafc;
    border-radius: 15px;
    padding: 8px;
    margin-bottom: 2rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.stTabs [data-baseweb="tab"] {
    height: 50px;
    padding: 0px 24px;
    background-color: transparent;
    border-radius: 10px;
    color: #64748b;
    font-weight: 500;
    font-size: 16px;
    transition: all 0.3s ease;
    border: none;
}

.stTabs [aria-selected="true"] {
    background: linear-gradient(135deg, #667eea, #764ba2) !important;
    color: white !important;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    transform: translateY(-1px);
}

/* Button styling */
.stButton > button {
    background: linear-gradient(135deg, #667eea, #764ba2) !important;
    color: white !important;
    border: none !important;
    border-radius: 12px !important;
    padding: 12px 24px !important;
    font-weight: 600 !important;
    transition: all 0.3s ease !important;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3) !important;
}

.stButton > button:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4) !important;
}

/* Input styling */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea,
.stSelectbox > div > div > select {
    border: 2px solid #e2e8f0 !important;
    border-radius: 12px !important;
    padding: 12px 16px !important;
    transition: all 0.3s ease !important;
    background: white !important;
}

.stTextInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus,
.stSelectbox > div > div > select:focus {
    border-color: #667eea !important;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1) !important;
}

/* Selectbox styling */
.stSelectbox > div > div {
    background: white !important;
    border-radius: 12px !important;
}

/* Info/Success/Error boxes */
.stInfo, .stSuccess, .stError, .stWarning {
    border-radius: 12px !important;
    border: none !important;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1) !important;
}

/* Metrics */
.metric-container {
    background: white;
    padding: 1rem;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    text-align: center;
}

/* Sidebar selectbox fix */
.css-1d391kg .stSelectbox > div > div {
    background: rgba(255, 255, 255, 0.1) !important;
    color: white !important;
    border: 1px solid rgba(255, 255, 255, 0.2) !important;
}

.css-1d391kg .stSelectbox option {
    background: #2d3748 !important;
    color: white !important;
}

/* Sidebar input fields */
.css-1d391kg .stTextInput > div > div > input {
    background: rgba(255, 255, 255, 0.1) !important;
    color: white !important;
    border: 1px solid rgba(255, 255, 255, 0.2) !important;
}

.css-1d391kg .stTextInput > div > div > input::placeholder {
    color: rgba(255, 255, 255, 0.6) !important;
}

/* Hide default Streamlit elements */
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header {visibility: hidden;}

/* Responsive design */
@media (max-width: 768px) {
    .block-container {
        margin: 1rem !important;
        padding: 1rem !important;
    }
    
    .main-title {
        font-size: 2rem;
    }
}
</style>

<script>
// Hamburger menu functionality
function toggleSidebar() {
    const sidebar = parent.document.querySelector('[data-testid="stSidebar"]');
    const hamburger = document.querySelector('.hamburger-menu');
    
    if (sidebar) {
        if (sidebar.style.display === 'none' || sidebar.style.marginLeft === '-21rem') {
            sidebar.style.display = 'block';
            sidebar.style.marginLeft = '0';
        } else {
            sidebar.style.marginLeft = '-21rem';
        }
    }
}
</script>
""", unsafe_allow_html=True)

# Custom hamburger menu
st.markdown("""
<div class="hamburger-menu" onclick="toggleSidebar()">
    <div class="hamburger-line"></div>
    <div class="hamburger-line"></div>
    <div class="hamburger-line"></div>
</div>
""", unsafe_allow_html=True)

# Header with improved styling
st.markdown('<h1 class="main-title">🤖 AI Multi-Model Chat & 📄 Document Generator</h1>', unsafe_allow_html=True)
st.markdown('<p class="sub-title">✨ Supporting OpenAI • Ollama • HuggingFace • Free Open Source Models</p>', unsafe_allow_html=True)

# Initialize session state
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "docs_generated" not in st.session_state:
    st.session_state.docs_generated = 0

# SIDEBAR WITH MODEL CONFIGURATION
with st.sidebar:
    st.markdown("# 🎯 Model Configuration")
    st.markdown("---")
    
    # Provider selection with better styling
    st.markdown("### 🔧 Choose AI Provider")
    provider = st.selectbox(
        "Provider",
        ["ollama", "huggingface", "openai"],
        help="Select your preferred AI model provider",
        label_visibility="collapsed"
    )
    
    # Model configuration based on provider
    if provider == "ollama":
        st.markdown("### 🦙 Ollama (Local & Free)")
        models = ["llama2", "llama2-13b", "codellama", "mistral", "neural-chat"]
        model = st.selectbox("Model", models, label_visibility="collapsed")
        
        # Check Ollama status
        status = multi_model.check_provider_status("ollama")
        if status:
            st.success("🟢 Ollama Online")
        else:
            st.error("🔴 Ollama Offline")
            with st.expander("🛠️ Quick Setup"):
                st.markdown("""
                **Install Ollama:**
                1. Download: [ollama.ai](https://ollama.ai)
                2. Install & start Ollama
                3. Run: `ollama pull llama2`
                4. Refresh this page
                """)
        
        api_key = None
        
    elif provider == "huggingface":
        st.markdown("### 🤗 HuggingFace (Free)")
        models = [
            "microsoft/DialoGPT-medium",
            "facebook/blenderbot-400M-distill",
            "microsoft/DialoGPT-large"
        ]
        model = st.selectbox("Model", models, label_visibility="collapsed")
        api_key = st.text_input("🔑 HF Token (Optional)", type="password", help="For higher rate limits")
        st.success("🟢 Available")
        
    else:  # openai
        st.markdown("### 🤖 OpenAI (Paid)")
        models = ["gpt-3.5-turbo", "gpt-4"]
        model = st.selectbox("Model", models, label_visibility="collapsed")
        api_key = st.text_input("🔑 OpenAI API Key", type="password", help="Required for OpenAI models")
    
    st.markdown("---")
    st.markdown("### 📊 Session Stats")
    chat_count = len([msg for msg in st.session_state.chat_history if msg[0] == "You"])
    
    # Custom metrics styling
    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"""
        <div class="metric-container">
            <h3 style="color: #667eea; margin: 0;">{chat_count}</h3>
            <p style="margin: 0; color: #64748b;">Messages</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-container">
            <h3 style="color: #667eea; margin: 0;">{st.session_state.docs_generated}</h3>
            <p style="margin: 0; color: #64748b;">Documents</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    st.markdown("### 🚀 Quick Help")
    st.markdown("""
    **🆓 Free Options:**
    - **Ollama**: Local AI models
    - **HuggingFace**: Cloud models
    
    **💰 Paid Option:**
    - **OpenAI**: Premium models
    
    **💡 Tip:** Use the hamburger menu (☰) at top-left to toggle this sidebar!
    """)

# Main content tabs
tab1, tab2 = st.tabs(["💬 Multi-Model Chat", "📄 Document Creator"])

with tab1:
    st.markdown(f"### 🤖 Chat with {provider.title()}: {model}")
    
    # Current configuration display with better styling
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(f"""
        <div class="metric-container">
            <h4 style="color: #667eea; margin: 0;">Provider</h4>
            <p style="margin: 0; font-weight: 600;">{provider.title()}</p>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown(f"""
        <div class="metric-container">
            <h4 style="color: #667eea; margin: 0;">Model</h4>
            <p style="margin: 0; font-weight: 600;">{model}</p>
        </div>
        """, unsafe_allow_html=True)
    with col3:
        status = multi_model.check_provider_status(provider)
        status_color = "#10b981" if status else "#ef4444"
        status_text = "Online" if status else "Offline"
        st.markdown(f"""
        <div class="metric-container">
            <h4 style="color: #667eea; margin: 0;">Status</h4>
            <p style="margin: 0; font-weight: 600; color: {status_color};">{status_text}</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Chat interface
    if st.button("🗑️ Clear Chat"):
        st.session_state.chat_history = []
        st.rerun()
    
    # Chat input
    user_input = st.text_input(
        "💭 Your message:",
        placeholder=f"Chat with {provider.title()} {model}..."
    )
    
    if user_input:
        if provider == "openai" and not api_key:
            st.error("❌ Please enter your OpenAI API key in the sidebar")
        else:
            with st.spinner(f"🧠 {model} is thinking..."):
                try:
                    response = multi_model.generate_response(
                        user_input, 
                        provider, 
                        model, 
                        api_key=api_key, 
                        hf_token=api_key if provider == "huggingface" else None
                    )
                    
                    st.session_state.chat_history.append(("You", user_input))
                    st.session_state.chat_history.append(("AI", response))
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
    
    # Display chat history
    if st.session_state.chat_history:
        st.markdown("### 💬 Conversation History")
        for speaker, message in reversed(st.session_state.chat_history[-10:]):
            if speaker == "You":
                st.markdown(f"**👤 You:** {message}")
            else:
                st.markdown(f"**🤖 {provider.title()}:** {message}")
            st.markdown("---")
    else:
        st.info("Start a conversation by typing a message above!")

with tab2:
    st.markdown(f"### 📝 Document Generator using {provider.title()}")
    
    # Document type
    doc_type = st.selectbox(
        "Document Type",
        ["Business Letter", "Report", "Article", "Proposal", "Technical Documentation"]
    )
    
    # Content prompt
    prompt = st.text_area(
        "Describe your document:",
        placeholder="Enter detailed instructions for the document you want to generate...",
        height=150
    )
    
    if st.button("🚀 Generate Document") and prompt:
        if provider == "openai" and not api_key:
            st.error("❌ Please enter your OpenAI API key in the sidebar")
        else:
            with st.spinner(f"📝 Generating with {model}..."):
                try:
                    # Enhanced prompt
                    enhanced_prompt = f"Create a professional {doc_type.lower()} based on: {prompt}"
                    
                    # Generate content
                    content = multi_model.generate_response(
                        enhanced_prompt, 
                        provider, 
                        model, 
                        api_key=api_key, 
                        hf_token=api_key if provider == "huggingface" else None
                    )
                    
                    # Create document
                    doc_file = generate_docx(content, doc_title=f"{doc_type} - Generated by {provider.title()}")
                    st.session_state.docs_generated += 1
                    
                    # Preview
                    with st.expander("📖 Preview", expanded=True):
                        st.markdown(content)
                    
                    # Download
                    with open(doc_file, "rb") as f:
                        st.download_button(
                            "📥 Download Document",
                            data=f,
                            file_name=f"{doc_type.replace(' ', '_')}_{provider}.docx",
                            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        )
                    
                    # Stats
                    words = len(content.split())
                    st.success(f"✅ Generated {words} words successfully!")
                    
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
    
    if not prompt:
        st.info("💡 Enter a description above to generate a professional document!")

# Sidebar visibility reminder
if st.sidebar:
    pass  # Sidebar is visible
else:
    st.warning("👈 **Sidebar not visible?** Look for the arrow (>) at the top-left corner to expand the model configuration panel.")
