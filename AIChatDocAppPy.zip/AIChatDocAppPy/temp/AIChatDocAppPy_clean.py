import streamlit as st
from utils.openai_helper import generate_response
from utils.multi_model_helper import multi_model
from utils.doc_generator import generate_docx
import time

st.set_page_config(
    page_title="AI Multi-Model Chat & Doc Generator",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Clean and professional CSS styling
st.markdown(
    """
    <style>
        /* Import Google Fonts */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        /* Main background */
        .stApp {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', sans-serif;
        }
        
        /* Container styling */
        .block-container {
            padding: 2rem 3rem 4rem;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
            margin: 1rem auto;
            max-width: 1200px;
        }
        
        /* Header styling */
        .main-header {
            text-align: center;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .sub-header {
            text-align: center;
            color: #6b7280;
            font-size: 1.2rem;
            margin-bottom: 2rem;
            font-weight: 400;
        }
        
        /* Tab styling */
        .stTabs [data-baseweb="tab-list"] {
            gap: 24px;
            background-color: #f8fafc;
            border-radius: 15px;
            padding: 8px;
            margin-bottom: 2rem;
        }
        
        .stTabs [data-baseweb="tab"] {
            height: 60px;
            padding: 0px 24px;
            background-color: transparent;
            border-radius: 12px;
            color: #64748b;
            font-weight: 500;
            font-size: 16px;
            transition: all 0.3s ease;
            border: none;
        }
        
        .stTabs [aria-selected="true"] {
            background: linear-gradient(135deg, #667eea, #764ba2) !important;
            color: white !important;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transform: translateY(-2px);
        }
        
        /* Input styling */
        .stTextInput > div > div > input {
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 15px 20px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .stTextInput > div > div > input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-1px);
        }
        
        .stTextArea > div > div > textarea {
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 15px 20px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            min-height: 120px;
        }
        
        .stTextArea > div > div > textarea:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        /* Button styling */
        .stButton > button {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            text-transform: none;
        }
        
        .stButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
            background: linear-gradient(135deg, #5a67d8, #6b46c1);
        }
        
        .stDownloadButton > button {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }
        
        .stDownloadButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
        }
        
        /* Chat message styling */
        .chat-message {
            padding: 15px 20px;
            margin: 10px 0;
            border-radius: 15px;
            animation: fadeInUp 0.5s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .user-message {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            margin-left: 20%;
            border-bottom-right-radius: 5px;
        }
        
        .ai-message {
            background: linear-gradient(145deg, #f8fafc, #e2e8f0);
            color: #374151;
            margin-right: 20%;
            border-bottom-left-radius: 5px;
        }
        
        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Feature cards */
        .feature-card {
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border-radius: 15px;
            padding: 25px;
            margin: 15px 0;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        /* Status indicators */
        .status-success {
            color: #10b981;
            font-weight: 600;
        }
        
        .status-processing {
            color: #f59e0b;
            font-weight: 600;
        }
        
        .status-error {
            color: #ef4444;
            font-weight: 600;
        }
        
        /* Sidebar styling */
        .css-1d391kg {
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        
        /* Hide Streamlit branding */
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        header {visibility: hidden;}
    </style>
""",
    unsafe_allow_html=True,
)

# Header
st.markdown('<h1 class="main-header">🤖 AI Multi-Model Chat & 📄 Document Generator</h1>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">✨ Supporting OpenAI • Ollama • HuggingFace • Free Open Source Models</p>', unsafe_allow_html=True)

# Embedded API key (like in original)
api_key = "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"

# Initialize session state
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "docs_generated" not in st.session_state:
    st.session_state.docs_generated = 0

# Sidebar with model selection
with st.sidebar:
    st.markdown("### 🎯 Model Configuration")
    
    # Model provider selection (default to OpenAI like original)
    provider = st.selectbox(
        "🔧 AI Provider",
        ["openai", "ollama", "huggingface"],
        help="Choose your AI model provider"
    )
    
    # Model configuration based on provider
    if provider == "openai":
        st.markdown("#### 🤖 OpenAI (Ready to Use)")
        models = list(multi_model.models["openai"].keys())
        # Default to gpt-3.5-turbo like original
        default_model_index = models.index("gpt-3.5-turbo") if "gpt-3.5-turbo" in models else 0
        model = st.selectbox("Model", models, index=default_model_index, help="OpenAI models")
        
        st.success("🟢 API Key Configured")
        st.info("💡 Using embedded API key (like original version)")
        
        # Use the embedded API key
        user_api_key = api_key
        
    elif provider == "ollama":
        st.markdown("#### 🦙 Ollama (Local & Free)")
        models = list(multi_model.models["ollama"].keys())
        model = st.selectbox("Model", models, help="Local Ollama models")
        
        # Check Ollama status
        ollama_status = multi_model.check_provider_status("ollama")
        if ollama_status:
            st.success("🟢 Ollama is running!")
        else:
            st.error("🔴 Ollama not detected")
            with st.expander("🛠️ Setup Ollama"):
                st.markdown("""
                **Quick Setup:**
                1. Download from [ollama.ai](https://ollama.ai)
                2. Install and start Ollama
                3. Run: `ollama pull llama2`
                4. Refresh this page
        user_api_key = api_key
        
    elif provider == "ollama":
        st.markdown("#### 🦙 Ollama (Local & Free)")
        models = list(multi_model.models["ollama"].keys())
        model = st.selectbox("Model", models, help="Local Ollama models")
        
        # Check Ollama status
        ollama_status = multi_model.check_provider_status("ollama")
        if ollama_status:
            st.success("🟢 Ollama is running!")
        else:
            st.error("🔴 Ollama not detected")
            with st.expander("🛠️ Setup Ollama"):
                st.markdown("""
                **Quick Setup:**
                1. Download from [ollama.ai](https://ollama.ai)
                2. Install and start Ollama
                3. Run: `ollama pull llama2`
                4. Refresh this page
                """)
        
        user_api_key = None
        
    elif provider == "huggingface":
        st.markdown("#### 🤗 HuggingFace (Free)")
        models = list(multi_model.models["huggingface"].keys())
        model = st.selectbox("Model", models, help="Free HuggingFace models")
        
        st.success("🟢 Available")
        
        user_api_key = st.text_input(
            "🔑 HF Token (Optional)", 
            type="password",
            help="Optional: For higher rate limits"
        )
    
    st.markdown("---")
    st.markdown("### 📊 Session Stats")
    
    if st.session_state.chat_history:
        chat_count = len([msg for msg in st.session_state.chat_history if msg[0] == "You"])
        st.metric("Messages Sent", chat_count)
    
    st.metric("Documents Created", st.session_state.docs_generated)
    
    st.markdown("---")
    st.markdown("### 🚀 Features")
    st.markdown("""
    **Multi-Model Chat**
    - Compare different AI models
    - Free local models (Ollama)
    - Cloud-based models
    
    **Document Generation**
    - AI-powered content creation
    - Professional formatting
    - Multiple model support
    """)

# Main content tabs
tab1, tab2 = st.tabs(["💬 Multi-Model Chat", "📄 Document Creator"])

with tab1:
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown(f"### 🤖 AI Assistant ({provider.title()}: {model})")
        st.markdown("*Ask me anything! Choose different models to compare responses.*")
    
    with col2:
        if st.button("🗑️ Clear Chat", help="Clear conversation history"):
            st.session_state.chat_history = []
            st.rerun()

    # Current model info
    col1, col2, col3 = st.columns(3)
    with col1:
        st.info(f"**Provider:** {provider.title()}")
    with col2:
        st.info(f"**Model:** {model}")
    with col3:
        status = multi_model.check_provider_status(provider)
        if status:
            st.success("**Status:** Online")
        else:
            st.error("**Status:** Offline")

    # Chat input
    user_input = st.text_input(
        "💭 What's on your mind?", 
        placeholder=f"Type your message here... (Using {provider.title()}: {model})",
        key="chat_input"
    )

    if user_input:
        # Validation - simplified since we have embedded API key for OpenAI
        if provider == "ollama" and not multi_model.check_provider_status("ollama"):
            st.error("❌ Ollama is not running. Please start Ollama first.")
        else:
            with st.spinner(f"🧠 {model} is thinking..."):
                try:
                    response = multi_model.generate_response(
                        user_input, 
                        provider, 
                        model, 
                        api_key=user_api_key, 
                        hf_token=user_api_key if provider == "huggingface" else None
                    )
                    
                    st.session_state.chat_history.append(("You", user_input))
                    st.session_state.chat_history.append(("AI", response))
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")

    # Chat display
    if st.session_state.chat_history:
        st.markdown("### 💬 Conversation")
        
        for i, (speaker, message) in enumerate(reversed(st.session_state.chat_history[-10:])):
            if speaker == "You":
                st.markdown(f"""
                <div class="chat-message user-message">
                    <strong>👤 You:</strong><br>{message}
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="chat-message ai-message">
                    <strong>🤖 {provider.title()} ({model}):</strong><br>{message}
                </div>
                """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="feature-card">
            <h4>👋 Welcome to Multi-Model AI Chat!</h4>
            <p>You're currently using <strong>{provider.title()}</strong> with the <strong>{model}</strong> model.</p>
            <p>Start a conversation by typing a message above. Here are some ideas:</p>
            <ul>
                <li>🔬 Ask about science and technology</li>
                <li>💡 Get creative writing ideas</li>
                <li>🎯 Request help with problem-solving</li>
                <li>📚 Learn about any topic</li>
                <li>🤔 Compare responses from different models</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

with tab2:
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown(f"### 📝 AI Document Generator ({provider.title()})")
        st.markdown("*Transform your ideas into professional documents.*")
    
    with col2:
        st.metric("📄 Current Model", f"{provider.title()}", delta=model)
    
    # Document type selector
    doc_type = st.selectbox(
        "📋 Document Type",
        ["Business Letter", "Report", "Article", "Proposal", "Meeting Notes", "Creative Writing", "Technical Documentation", "Custom"],
        help="Choose the type of document you want to generate"
    )
    
    # Enhanced prompt input
    prompt = st.text_area(
        f"✍️ Describe your {doc_type.lower()}:",
        placeholder=f"Provide details about the {doc_type.lower()} you want to create. Include key points, audience, tone, and any specific requirements...",
        height=150,
        help="The more detailed your prompt, the better the output!"
    )
    
    # Generate document
    if st.button("🚀 Generate Document", use_container_width=True) and prompt:
        # Validation - simplified since we have embedded API key for OpenAI
        if provider == "ollama" and not multi_model.check_provider_status("ollama"):
            st.error("❌ Ollama is not running. Please start Ollama first.")
        else:
            # Enhanced prompt
            enhanced_prompt = f"""
            Create a professional {doc_type.lower()} based on the following requirements:
            
            {prompt}
            
            Please ensure the document is well-structured, professional, and meets the specified requirements.
            """
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                status_text.markdown('<p class="status-processing">🔄 Initializing AI generation...</p>', unsafe_allow_html=True)
                progress_bar.progress(25)
                time.sleep(0.5)
                
                status_text.markdown(f'<p class="status-processing">🧠 {model} is crafting your document...</p>', unsafe_allow_html=True)
                progress_bar.progress(50)
                
                # Generate content
                output_text = multi_model.generate_response(
                    enhanced_prompt, 
                    provider, 
                    model, 
                    api_key=api_key, 
                    hf_token=api_key if provider == "huggingface" else None
                )
                progress_bar.progress(75)
                
                status_text.markdown('<p class="status-processing">📄 Creating Word document...</p>', unsafe_allow_html=True)
                docx_file = generate_docx(output_text, doc_title=f"{doc_type} - Generated by {provider.title()}")
                progress_bar.progress(100)
                
                status_text.markdown('<p class="status-success">✅ Document generated successfully!</p>', unsafe_allow_html=True)
                st.session_state.docs_generated += 1
                
                # Document preview
                with st.expander("👀 Preview Generated Content", expanded=True):
                    st.markdown(f"### 📖 Document Preview (Generated by {provider.title()} - {model})")
                    st.markdown(output_text)
                
                # Download section
                col1, col2, col3 = st.columns([1, 2, 1])
                
                with col2:
                    with open(docx_file, "rb") as f:
                        st.download_button(
                            label="📥 Download DOCX File",
                            data=f,
                            file_name=f"generated_{doc_type.lower().replace(' ', '_')}_{provider}.docx",
                            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            use_container_width=True
                        )
                
                # Success metrics
                word_count = len(output_text.split())
                char_count = len(output_text)
                
                col1, col2, col3 = st.columns(3)
                col1.metric("📝 Words", word_count)
                col2.metric("🔤 Characters", char_count)
                col3.metric("📄 Pages (Est.)", max(1, word_count // 250))
                
            except Exception as e:
                status_text.markdown(f'<p class="status-error">❌ Error: {str(e)}</p>', unsafe_allow_html=True)
                progress_bar.empty()
    
    else:
        # Feature showcase
        st.markdown(f"""
        <div class="feature-card">
            <h4>🎯 Multi-Model Document Generation</h4>
            <p>Currently using <strong>{provider.title()}</strong> with <strong>{model}</strong> model.</p>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px;">
                <div>
                    <h5>📋 Document Types</h5>
                    <ul>
                        <li>Business Letters</li>
                        <li>Reports & Proposals</li>
                        <li>Articles & Content</li>
                        <li>Technical Documentation</li>
                    </ul>
                </div>
                <div>
                    <h5>⚡ Multi-Model Features</h5>
                    <ul>
                        <li>OpenAI GPT models</li>
                        <li>Free Ollama models</li>
                        <li>HuggingFace models</li>
                        <li>Professional formatting</li>
                    </ul>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
