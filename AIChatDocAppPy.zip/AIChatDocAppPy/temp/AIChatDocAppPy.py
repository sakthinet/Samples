﻿import streamlit as st
from utils.openai_helper import generate_response
from utils.multi_model_helper import multi_model
from utils.doc_generator import generate_docx
import time

st.set_page_config(
    page_title="AI Chat & Doc Generator",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Modern CSS styling with gradients, an    # Chat input with enhanced styling
    user_input = st.text_input(
        "💭 What's on your mind?", 
        placeholder=f"Type your message here... (Using {provider.title()} - {model})",
        key="chat_input"
    )

    if user_input:
        # Add loading animation
        with st.spinner(f"🧠 {model} is thinking..."):
            try:
                # Use multi-model helper instead of OpenAI only
                if provider == "openai":
                    if not api_key:
                        st.error("❌ Please enter your OpenAI API key in the sidebar")
                    else:
                        response = multi_model.generate_response(user_input, provider, model, api_key=api_key)
                elif provider == "huggingface":
                    response = multi_model.generate_response(user_input, provider, model, hf_token=api_key)
                else:  # ollama
                    response = multi_model.generate_response(user_input, provider, model)
                
                st.session_state.chat_history.append(("You", user_input))
                st.session_state.chat_history.append(("AI", response))
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")eractive elements
st.markdown(
    """
    <style>
        /* Import Google Fonts */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        /* Main background with gradient */
        .stApp {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', sans-serif;
        }
        
        /* Container styling */
        .block-container {
            padding: 2rem 3rem 4rem;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
            margin: 1rem auto;
            max-width: 1200px;
        }
        
        /* Header styling */
        .main-header {
            text-align: center;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }
        
        .sub-header {
            text-align: center;
            color: #6b7280;
            font-size: 1.2rem;
            margin-bottom: 2rem;
            font-weight: 400;
        }
        
        /* Tab styling */
        .stTabs [data-baseweb="tab-list"] {
            gap: 24px;
            background-color: #f8fafc;
            border-radius: 15px;
            padding: 8px;
            margin-bottom: 2rem;
        }
        
        .stTabs [data-baseweb="tab"] {
            height: 60px;
            padding: 0px 24px;
            background-color: transparent;
            border-radius: 12px;
            color: #64748b;
            font-weight: 500;
            font-size: 16px;
            transition: all 0.3s ease;
            border: none;
        }
        
        .stTabs [aria-selected="true"] {
            background: linear-gradient(135deg, #667eea, #764ba2) !important;
            color: white !important;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transform: translateY(-2px);
        }
        
        /* Input styling */
        .stTextInput > div > div > input {
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 15px 20px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .stTextInput > div > div > input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-1px);
        }
        
        .stTextArea > div > div > textarea {
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 15px 20px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            min-height: 120px;
        }
        
        .stTextArea > div > div > textarea:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        /* Button styling */
        .stButton > button {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            text-transform: none;
        }
        
        .stButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
            background: linear-gradient(135deg, #5a67d8, #6b46c1);
        }
        
        .stDownloadButton > button {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }
        
        .stDownloadButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
        }
        
        /* Chat message styling */
        .chat-message {
            padding: 15px 20px;
            margin: 10px 0;
            border-radius: 15px;
            animation: fadeInUp 0.5s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .user-message {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            margin-left: 20%;
            border-bottom-right-radius: 5px;
        }
        
        .ai-message {
            background: linear-gradient(145deg, #f8fafc, #e2e8f0);
            color: #374151;
            margin-right: 20%;
            border-bottom-left-radius: 5px;
        }
        
        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.5;
            }
        }
        
        /* Loading spinner */
        .custom-spinner {
            text-align: center;
            font-size: 18px;
            margin: 20px 0;
            color: #667eea;
            animation: pulse 2s infinite;
        }
        
        /* Feature cards */
        .feature-card {
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border-radius: 15px;
            padding: 25px;
            margin: 15px 0;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        /* Status indicators */
        .status-success {
            color: #10b981;
            font-weight: 600;
        }
        
        .status-processing {
            color: #f59e0b;
            font-weight: 600;
        }
        
        /* Sidebar styling */
        .css-1d391kg {
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        
        /* Hide Streamlit branding */
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        header {visibility: hidden;}
    </style>
""",
    unsafe_allow_html=True,
)

# Modern header with animations
st.markdown('<h1 class="main-header">🤖 AI Chat & � Document Generator</h1>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">✨ Powered by OpenAI GPT-3.5 • Create intelligent conversations and professional documents</p>', unsafe_allow_html=True)

# Sidebar with app info and model selection
with st.sidebar:
    st.markdown("### 🤖 AI Model Selection")
    
    # Model provider selection
    provider = st.selectbox(
        "🏢 Choose Provider",
        ["ollama", "huggingface", "openai"],
        format_func=lambda x: {
            "ollama": "🦙 Ollama (Local & Free)",
            "huggingface": "🤗 HuggingFace (Free API)",
            "openai": "🔥 OpenAI (Paid)"
        }[x],
        help="Select your preferred AI model provider"
    )
    
    # Get available models
    available_models = multi_model.get_available_models()
    
    if provider == "ollama":
        ollama_status = multi_model.check_ollama_status()
        if ollama_status:
            st.success("✅ Ollama is running")
            if available_models["ollama"]:
                model = st.selectbox("🤖 Choose Model", available_models["ollama"])
            else:
                st.warning("⚠️ No models found. Pull models first!")
                st.code("ollama pull llama2")
                model = "llama2:latest"
        else:
            st.error("❌ Ollama not running")
            st.markdown("**Installation:**")
            st.markdown("1. Download from [ollama.ai](https://ollama.ai)")
            st.markdown("2. Run `ollama serve`")
            st.markdown("3. Pull models: `ollama pull llama2`")
            model = "llama2:latest"
            
    elif provider == "huggingface":
        model = st.selectbox(
            "🤖 Choose Model", 
            available_models["huggingface"],
            format_func=lambda x: x.split("/")[-1]
        )
        hf_token = st.text_input(
            "🔑 HuggingFace Token (Optional)", 
            type="password",
            help="Optional: For private models or higher rate limits"
        )
    else:  # openai
        model = st.selectbox("🤖 Choose Model", available_models["openai"])
        openai_api_key = st.text_input(
            "🔑 OpenAI API Key", 
            type="password",
            value="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"
        )
    
    # Model information
    if provider in ["ollama", "huggingface"]:
        model_info = multi_model.get_model_info(provider, model)
        if model_info:
            st.markdown("### 📊 Model Info")
            st.markdown(f"**Type:** {model_info.get('type', 'Unknown')}")
            st.markdown(f"**Size:** {model_info.get('size', 'Unknown')}")
            st.markdown(f"**Description:** {model_info.get('description', 'No description')}")
    
    st.markdown("---")
    st.markdown("### 🚀 Features")
    st.markdown("""
    **🗨️ Smart Chat**
    - Multiple AI models
    - Local & cloud options
    - Persistent chat history
    
    **📄 Document Generation**
    - AI-powered content creation
    - Professional Word documents
    - Multi-model support
    
    **⚡ Supported Models**
    - 🦙 Ollama (Local, Free)
    - 🤗 HuggingFace (API, Free)
    - 🔥 OpenAI (API, Paid)
    """)
    
    st.markdown("---")
    st.markdown("### 📊 Session Stats")
    if "chat_history" in st.session_state:
        chat_count = len([msg for msg in st.session_state.chat_history if msg[0] == "You"])
        st.metric("Messages Sent", chat_count)
    
    if "docs_generated" not in st.session_state:
        st.session_state.docs_generated = 0
    st.metric("Documents Created", st.session_state.docs_generated)

# Store API keys in session state
if provider == "openai":
    api_key = openai_api_key
elif provider == "huggingface":
    api_key = hf_token if 'hf_token' in locals() else None
else:
    api_key = None
tab1, tab2 = st.tabs(["� Smart Chat", "📄 Document Creator"])

# Initialize chat history
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

with tab1:
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown("### 🤖 AI Assistant")
        st.markdown("*Ask me anything! I'm here to help with questions, advice, or just a friendly chat.*")
    
    with col2:
        if st.button("🗑️ Clear Chat", help="Clear conversation history"):
            st.session_state.chat_history = []
            st.rerun()

    # Chat input with enhanced styling
    user_input = st.text_input(
        "� What's on your mind?", 
        placeholder="Type your message here... (e.g., 'Explain quantum computing' or 'Help me plan a vacation')",
        key="chat_input"
    )

    if user_input and api_key:
        # Add loading animation
        with st.spinner("🧠 AI is thinking..."):
            try:
                response = generate_response(user_input, api_key)
                st.session_state.chat_history.append(("You", user_input))
                st.session_state.chat_history.append(("AI", response))
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")

    # Enhanced chat display
    if st.session_state.chat_history:
        st.markdown("### 💬 Conversation")
        
        # Create a container for chat messages
        chat_container = st.container()
        
        with chat_container:
            for i, (speaker, message) in enumerate(reversed(st.session_state.chat_history[-10:])):  # Show last 10 messages
                if speaker == "You":
                    st.markdown(f"""
                    <div class="chat-message user-message">
                        <strong>👤 You:</strong><br>{message}
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="chat-message ai-message">
                        <strong>🤖 AI Assistant:</strong><br>{message}
                    </div>
                    """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="feature-card">
            <h4>👋 Welcome to AI Chat!</h4>
            <p>Start a conversation by typing a message above. Here are some ideas:</p>
            <ul>
                <li>🔬 Ask about science and technology</li>
                <li>💡 Get creative writing ideas</li>
                <li>🎯 Request help with problem-solving</li>
                <li>📚 Learn about any topic</li>
                <li>🤔 Seek advice and recommendations</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)

with tab2:
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### 📝 AI Document Generator")
        st.markdown("*Transform your ideas into professional documents with AI assistance.*")
    
    with col2:
        st.metric("📄 Success Rate", "99.9%", delta="High Quality")
    
    # Document type selector
    doc_type = st.selectbox(
        "� Document Type",
        ["Business Letter", "Report", "Article", "Proposal", "Meeting Notes", "Creative Writing", "Technical Documentation", "Custom"],
        help="Choose the type of document you want to generate"
    )
    
    # Enhanced prompt input
    if doc_type == "Custom":
        prompt = st.text_area(
            "✍️ Enter your detailed instruction for document generation:",
            placeholder="Describe exactly what you want the AI to write. Be specific about tone, style, length, and content...",
            height=150,
            help="The more detailed your prompt, the better the output!"
        )
    else:
        prompt = st.text_area(
            f"✍️ Describe your {doc_type.lower()}:",
            placeholder=f"Provide details about the {doc_type.lower()} you want to create. Include key points, audience, tone, and any specific requirements...",
            height=150,
            help="Provide context and specific details for better results"
        )
    
    # Advanced options in expander
    with st.expander("⚙️ Advanced Options"):
        col1, col2 = st.columns(2)
        
        with col1:
            tone = st.selectbox("🎭 Tone", ["Professional", "Casual", "Formal", "Friendly", "Technical", "Creative"])
            length = st.selectbox("📏 Length", ["Short (1-2 paragraphs)", "Medium (3-5 paragraphs)", "Long (6+ paragraphs)"])
        
        with col2:
            audience = st.selectbox("👥 Target Audience", ["General", "Business", "Academic", "Technical", "Students", "Executives"])
            format_style = st.selectbox("📐 Format", ["Standard", "Structured", "Bullet Points", "Narrative"])
    
    # Enhanced generation section
    if st.button("🚀 Generate Document", use_container_width=True) and prompt and api_key:
        # Enhanced prompt with context
        enhanced_prompt = f"""
        Create a {doc_type.lower()} with the following specifications:
        
        Content Request: {prompt}
        
        Style Guidelines:
        - Tone: {tone}
        - Length: {length}
        - Target Audience: {audience}
        - Format: {format_style}
        
        Please ensure the document is well-structured, professional, and meets the specified requirements.
        """
        
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        try:
            status_text.markdown('<p class="status-processing">� Initializing AI generation...</p>', unsafe_allow_html=True)
            progress_bar.progress(25)
            time.sleep(0.5)
            
            status_text.markdown('<p class="status-processing">🧠 AI is crafting your document...</p>', unsafe_allow_html=True)
            progress_bar.progress(50)
            
            output_text = generate_response(enhanced_prompt, api_key)
            progress_bar.progress(75)
            
            status_text.markdown('<p class="status-processing">📄 Creating Word document...</p>', unsafe_allow_html=True)
            docx_file = generate_docx(output_text)
            progress_bar.progress(100)
            
            status_text.markdown('<p class="status-success">✅ Document generated successfully!</p>', unsafe_allow_html=True)
            st.session_state.docs_generated += 1
            
            # Document preview
            with st.expander("👀 Preview Generated Content", expanded=True):
                st.markdown("### 📖 Document Preview")
                st.markdown(output_text)
            
            # Download section with enhanced styling
            col1, col2, col3 = st.columns([1, 2, 1])
            
            with col2:
                with open(docx_file, "rb") as f:
                    st.download_button(
                        label="📥 Download DOCX File",
                        data=f,
                        file_name=f"generated_{doc_type.lower().replace(' ', '_')}.docx",
                        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        use_container_width=True
                    )
            
            # Success metrics
            word_count = len(output_text.split())
            char_count = len(output_text)
            
            col1, col2, col3 = st.columns(3)
            col1.metric("📝 Words", word_count)
            col2.metric("🔤 Characters", char_count)
            col3.metric("📄 Pages (Est.)", max(1, word_count // 250))
            
        except Exception as e:
            status_text.markdown(f'<p style="color: #ef4444;">❌ Error: {str(e)}</p>', unsafe_allow_html=True)
            progress_bar.empty()
    
    else:
        # Feature showcase when no prompt
        st.markdown("""
        <div class="feature-card">
            <h4>🎯 Document Generation Features</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px;">
                <div>
                    <h5>📋 Document Types</h5>
                    <ul>
                        <li>Business Letters</li>
                        <li>Reports & Proposals</li>
                        <li>Articles & Content</li>
                        <li>Technical Documentation</li>
                    </ul>
                </div>
                <div>
                    <h5>⚡ Smart Features</h5>
                    <ul>
                        <li>AI-powered content</li>
                        <li>Professional formatting</li>
                        <li>Instant Word export</li>
                        <li>Customizable styles</li>
                    </ul>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
