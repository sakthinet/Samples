import streamlit as st
from utils.multi_model_helper import multi_model
from utils.doc_generator import generate_docx
import time
import datetime

# Set page config
st.set_page_config(
    page_title="AI Chat & Doc Generator",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Embedded OpenAI API key (like original version)
OPENAI_API_KEY = "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"

# Initialize session state
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "docs_generated" not in st.session_state:
    st.session_state.docs_generated = 0

# Modern CSS styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 20px;
        border-radius: 10px;
        text-align: center;
        margin-bottom: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .chat-message {
        padding: 10px;
        margin: 5px 0;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .user-message {
        background: linear-gradient(135deg, #74b9ff, #0984e3);
        color: white;
        margin-left: 20px;
    }
    
    .ai-message {
        background: linear-gradient(135deg, #fd79a8, #e84393);
        color: white;
        margin-right: 20px;
    }
    
    .stSelectbox > div > div {
        background: linear-gradient(135deg, #6c5ce7, #a29bfe);
        color: white;
    }
</style>
""", unsafe_allow_html=True)

# Main header
st.markdown('<h1 class="main-header">AI Multi-Model Chat & Document Generator</h1>', unsafe_allow_html=True)

# Sidebar configuration
with st.sidebar:
    st.markdown("### Model Configuration")
    
    # Provider selection
    provider = st.selectbox(
        "AI Provider",
        ["openai", "ollama", "huggingface"],
        index=0  # Default to OpenAI
    )
    
    # Provider-specific configuration
    if provider == "openai":
        st.markdown("#### OpenAI (Ready to Use)")
        model = st.selectbox(
            "Model",
            ["gpt-3.5-turbo", "gpt-4o-mini", "gpt-4"]
        )
        st.success("API Key Configured")
        st.info("Using embedded API key (like original version)")
        api_key = OPENAI_API_KEY
        
    elif provider == "ollama":
        st.markdown("#### Ollama (Local & Free)")
        available_models = multi_model.get_available_models()["ollama"]
        if available_models:
            model = st.selectbox("Model", available_models)
            st.success("Ollama is running!")
        else:
            st.error("Ollama not detected")
            with st.expander("Setup Ollama"):
                st.markdown("""
                1. Download Ollama from https://ollama.com
                2. Install and start it
                3. Run: `ollama pull llama2`
                4. Refresh this page
                """)
            model = "llama2"
        api_key = None
        
    elif provider == "huggingface":
        st.markdown("#### HuggingFace (Free)")
        model = st.selectbox(
            "Model", 
            ["microsoft/DialoGPT-large", "facebook/blenderbot-400M-distill", "gpt2"]
        )
        st.success("Available")
        api_key = st.text_input(
            "HF Token (Optional)", 
            type="password",
            help="Optional: Provides access to more models"
        )

    # Session stats
    st.markdown("### Session Stats")
    if st.session_state.chat_history:
        chat_count = len([msg for msg in st.session_state.chat_history if msg[0] == "You"])
        st.metric("Messages Sent", chat_count)
    
    st.metric("Documents Created", st.session_state.docs_generated)

# Main content tabs
tab1, tab2 = st.tabs(["Multi-Model Chat", "Document Creator"])

with tab1:
    st.markdown("### Chat Interface")
    
    # Display chat history
    if st.session_state.chat_history:
        for speaker, message in st.session_state.chat_history:
            if speaker == "You":
                st.markdown(f"""
                <div class="chat-message user-message">
                    <strong>You:</strong><br>{message}
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="chat-message ai-message">
                    <strong>{provider.title()} ({model}):</strong><br>{message}
                </div>
                """, unsafe_allow_html=True)
    else:
        st.info("Start a conversation by typing a message below!")

    # Chat input
    user_input = st.text_input(
        "What's on your mind?", 
        placeholder=f"Type your message here... (Using {provider.title()} - {model})",
        key="chat_input"
    )

    if user_input:
        # Add loading animation
        with st.spinner(f"{model} is thinking..."):
            try:
                # Validation - simplified since we have embedded API key for OpenAI
                if provider == "ollama" and not multi_model.check_provider_status("ollama"):
                    st.error("Ollama is not running. Please start Ollama first.")
                else:
                    # Generate response using multi-model helper
                    if provider == "openai":
                        response = multi_model.generate_response(user_input, provider, model, api_key=api_key)
                    elif provider == "huggingface":
                        response = multi_model.generate_response(user_input, provider, model, hf_token=api_key)
                    else:  # ollama
                        response = multi_model.generate_response(user_input, provider, model)
                    
                    st.session_state.chat_history.append(("You", user_input))
                    st.session_state.chat_history.append(("AI", response))
                    st.rerun()
                    
            except Exception as e:
                st.error(f"Error: {str(e)}")

    # Clear chat button
    if st.button("Clear Chat History") and st.session_state.chat_history:
        st.session_state.chat_history = []
        st.rerun()

with tab2:
    st.markdown("### Document Generator")
    
    # Document generation interface
    prompt = st.text_area(
        "Document Content Prompt",
        placeholder="Describe what you want to generate... (e.g., 'Write a business proposal for a new mobile app')",
        height=150
    )
    
    # Document options
    col1, col2 = st.columns(2)
    with col1:
        doc_type = st.selectbox(
            "Document Type",
            ["Business Report", "Technical Documentation", "Creative Writing", "Academic Paper", "General Content"]
        )
    
    with col2:
        doc_length = st.selectbox(
            "Length",
            ["Short (1-2 pages)", "Medium (3-5 pages)", "Long (5+ pages)"]
        )

    # Generate document
    if st.button("Generate Document", use_container_width=True) and prompt:
        # Validation - simplified since we have embedded API key for OpenAI
        if provider == "ollama" and not multi_model.check_provider_status("ollama"):
            st.error("Ollama is not running. Please start Ollama first.")
        else:
            # Create progress bar
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                # Generate content
                status_text.text("Generating content...")
                progress_bar.progress(30)
                
                # Create enhanced prompt
                enhanced_prompt = f"""
                Create a {doc_type.lower()} that is {doc_length.lower()} in length.
                
                Content Request: {prompt}
                
                Please provide well-structured, professional content with clear headings and detailed information.
                """
                
                # Generate response using multi-model helper
                if provider == "openai":
                    content = multi_model.generate_response(enhanced_prompt, provider, model, api_key=api_key)
                elif provider == "huggingface":
                    content = multi_model.generate_response(enhanced_prompt, provider, model, hf_token=api_key)
                else:  # ollama
                    content = multi_model.generate_response(enhanced_prompt, provider, model)
                
                progress_bar.progress(70)
                status_text.text("Creating document...")
                
                # Generate timestamp for filename
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"AI_Document_{timestamp}.docx"
                
                # Create document
                doc_buffer = generate_docx(
                    text=content,
                    filename=filename,
                    doc_title=f"{doc_type} - Generated by {provider.title()}"
                )
                
                progress_bar.progress(100)
                status_text.text("Document ready!")
                
                # Update stats
                st.session_state.docs_generated += 1
                
                # Success message
                st.success(f"Document generated successfully using {provider.title()} ({model})!")
                
                # Download button
                st.download_button(
                    label="Download Document",
                    data=doc_buffer,
                    file_name=filename,
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                )
                
                # Show preview
                with st.expander("Content Preview"):
                    st.text_area("Generated Content", content, height=200, disabled=True)
                    
            except Exception as e:
                st.error(f"Error generating document: {str(e)}")
            finally:
                progress_bar.empty()
                status_text.empty()

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #666; padding: 20px;">
    <p>AI Multi-Model Chat & Document Generator</p>
    <p>Powered by OpenAI, Ollama, and HuggingFace</p>
</div>
""", unsafe_allow_html=True)
