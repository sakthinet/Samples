# AI Multi-Model Chat & Document Generator

A powerful Streamlit application that provides multi-model AI chat capabilities and professional document generation.

## Features

### 🤖 Multi-Model AI Support
- **OpenAI**: GPT-3.5 Turbo, GPT-4 (API key embedded)
- **Ollama**: Local free models (llama2, mistral, codellama, etc.)
- **HuggingFace**: Cloud-based free models

### 📄 Document Generation
- AI-powered content creation
- Professional Word document formatting
- Multiple document types (Business, Technical, Creative, Academic)
- Instant download capabilities
- Progress tracking

### 🎨 Modern Interface
- Clean, professional design
- Gradient styling and animations
- Responsive layout
- Real-time chat interface

## Quick Start

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run Application**
   ```bash
   streamlit run AIChatDocApp.py
   ```

3. **Access Application**
   - Open your browser to `http://localhost:8501`
   - Start chatting immediately (OpenAI ready to use)
   - Generate professional documents

## Usage

### Chat Interface
- Select your preferred AI provider from the sidebar
- Type your message and get instant responses
- View conversation history with timestamps

### Document Creator
- Enter a content prompt
- Choose document type and length
- Click "Generate Document" for instant creation
- Download professional Word documents

## Project Structure

```
AIChatDocAppPy/
├── AIChatDocApp.py          # Main application
├── requirements.txt         # Dependencies
├── SETUP_GUIDE.md          # Setup instructions
├── utils/
│   ├── multi_model_helper.py # Multi-model AI support
│   └── doc_generator.py     # Document generation
└── temp/                    # Old/unused files
    ├── AIChatDocAppPy.py   # Original version
    ├── AIChatDocAppPy_*.py # Development versions
    └── *.pyproj, *.sln     # VS project files
```

## AI Providers Setup

### OpenAI (Ready to Use)
- API key is embedded in the application
- GPT-3.5 Turbo set as default
- No additional setup required

### Ollama (Optional - Local Models)
1. Download from https://ollama.com
2. Install and start Ollama
3. Pull models: `ollama pull llama2`
4. Refresh the application

### HuggingFace (Optional - Free Cloud Models)
- Works without token for basic models
- Add HF token in sidebar for more models
- Get token from https://huggingface.co/settings/tokens

## Dependencies

- streamlit
- openai
- requests
- python-docx
- transformers (for HuggingFace models)

## Development

The `temp/` folder contains previous development versions:
- Original version with embedded key
- Multi-model implementations
- UI design iterations
- Visual Studio project files

## License

This project is for educational and development purposes.
