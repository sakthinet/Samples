import requests
import json
import os
from typing import Dict, List, Optional
import time

class MultiModelHelper:
    """
    Multi-model AI helper supporting various free open-source models
    """
    
    def __init__(self):
        self.models = {
            "ollama": {
                "llama2": "llama2:latest",
                "llama2-13b": "llama2:13b",
                "codellama": "codellama:latest", 
                "mistral": "mistral:latest",
                "neural-chat": "neural-chat:latest",
                "starcode": "starcoder:latest",
                "orca-mini": "orca-mini:latest",
                "vicuna": "vicuna:latest"
            },
            "huggingface": {
                "microsoft/DialoGPT-medium": "microsoft/DialoGPT-medium",
                "microsoft/DialoGPT-large": "microsoft/DialoGPT-large",
                "facebook/blenderbot-400M-distill": "facebook/blenderbot-400M-distill",
                "microsoft/Phi-3-mini-4k-instruct": "microsoft/Phi-3-mini-4k-instruct",
                "google/flan-t5-large": "google/flan-t5-large"
            },
            "openai": {
                "gpt-3.5-turbo": "gpt-3.5-turbo",
                "gpt-4": "gpt-4"
            }
        }
        
        self.ollama_base_url = "http://localhost:11434"
        self.huggingface_api_url = "https://api-inference.huggingface.co/models"
    
    def get_available_models(self) -> Dict[str, List[str]]:
        """Get list of available models by provider"""
        available = {"ollama": [], "huggingface": [], "openai": []}
        
        # Check Ollama models
        try:
            response = requests.get(f"{self.ollama_base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                ollama_models = response.json().get("models", [])
                available["ollama"] = [model["name"] for model in ollama_models]
        except:
            pass
        
        # Add default HuggingFace models (always available via API)
        available["huggingface"] = list(self.models["huggingface"].keys())
        
        # Add OpenAI if API key is available
        available["openai"] = list(self.models["openai"].keys())
        
        return available
    
    def check_ollama_status(self) -> bool:
        """Check if Ollama is running locally"""
        try:
            response = requests.get(f"{self.ollama_base_url}/api/tags", timeout=3)
            return response.status_code == 200
        except:
            return False
    
    def check_provider_status(self, provider: str) -> bool:
        """Check if a provider is available and working"""
        if provider == "ollama":
            return self.check_ollama_status()
        elif provider == "huggingface":
            return True  # HuggingFace API is generally always available
        elif provider == "openai":
            return True  # OpenAI API availability depends on API key, checked during request
        else:
            return False
    
    def generate_ollama_response(self, prompt: str, model: str) -> str:
        """Generate response using Ollama local models"""
        try:
            payload = {
                "model": model,
                "prompt": prompt,
                "stream": False
            }
            
            response = requests.post(
                f"{self.ollama_base_url}/api/generate",
                json=payload,
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "No response generated")
            elif response.status_code == 404:
                return f"❌ Model '{model}' not found. Please install it with: `ollama pull {model}`"
            else:
                return f"❌ Ollama Error: {response.status_code} - {response.text}"
                
        except requests.exceptions.ConnectionError:
            return "❌ Cannot connect to Ollama. Please make sure Ollama is running.\n\n🛠️ Setup Instructions:\n1. Download from https://ollama.ai\n2. Install and start Ollama\n3. Run: `ollama pull llama2`"
        except requests.exceptions.Timeout:
            return "⏱️ Request timed out. The model might be loading. Please try again."
        except Exception as e:
            return f"❌ Ollama Error: {str(e)}"
    
    def generate_huggingface_response(self, prompt: str, model: str, hf_token: Optional[str] = None) -> str:
        """Generate response using HuggingFace Inference API"""
        try:
            headers = {}
            if hf_token:
                headers["Authorization"] = f"Bearer {hf_token}"
            
            payload = {
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": 500,
                    "temperature": 0.7,
                    "return_full_text": False
                }
            }
            
            response = requests.post(
                f"{self.huggingface_api_url}/{model}",
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # Handle different response formats
                if isinstance(result, list) and len(result) > 0:
                    if "generated_text" in result[0]:
                        return result[0]["generated_text"]
                    elif "text" in result[0]:
                        return result[0]["text"]
                elif isinstance(result, dict):
                    if "generated_text" in result:
                        return result["generated_text"]
                    elif "text" in result:
                        return result["text"]
                
                return str(result)
            else:
                return f"HuggingFace API Error: {response.status_code}"
                
        except Exception as e:
            return f"HuggingFace Error: {str(e)}"
    
    def generate_openai_response(self, prompt: str, model: str, api_key: str) -> str:
        """Generate response using OpenAI API"""
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"OpenAI Error: {str(e)}"
    
    def generate_response(self, prompt: str, provider: str, model: str, 
                         api_key: Optional[str] = None, hf_token: Optional[str] = None) -> str:
        """
        Universal response generation method
        
        Args:
            prompt: Input text prompt
            provider: Model provider ('ollama', 'huggingface', 'openai')
            model: Specific model name
            api_key: OpenAI API key (if using OpenAI)
            hf_token: HuggingFace token (optional, for private models)
        """
        
        if provider == "ollama":
            if not self.check_ollama_status():
                return "❌ Ollama is not running. Please install and start Ollama first.\n\nInstallation instructions:\n1. Download from https://ollama.ai\n2. Install and run 'ollama serve'\n3. Pull models with 'ollama pull llama2'"
            
            return self.generate_ollama_response(prompt, model)
            
        elif provider == "huggingface":
            return self.generate_huggingface_response(prompt, model, hf_token)
            
        elif provider == "openai":
            if not api_key:
                return "❌ OpenAI API key is required"
            return self.generate_openai_response(prompt, model, api_key)
            
        else:
            return f"❌ Unsupported provider: {provider}"
    
    def get_model_info(self, provider: str, model: str) -> Dict[str, str]:
        """Get information about a specific model"""
        model_info = {
            "ollama": {
                "llama2": {"description": "Meta's Llama 2 - Great for general conversations", "size": "3.8GB", "type": "General Purpose"},
                "mistral": {"description": "Mistral 7B - Fast and efficient", "size": "4.1GB", "type": "General Purpose"},
                "codellama": {"description": "Code Llama - Specialized for coding", "size": "3.8GB", "type": "Code Generation"},
                "neural-chat": {"description": "Intel's Neural Chat - Optimized for dialogue", "size": "4.1GB", "type": "Chat"},
                "orca-mini": {"description": "Microsoft's Orca Mini - Compact and efficient", "size": "1.9GB", "type": "General Purpose"}
            },
            "huggingface": {
                "microsoft/DialoGPT-medium": {"description": "Microsoft's dialogue model", "size": "350MB", "type": "Conversational"},
                "facebook/blenderbot-400M-distill": {"description": "Facebook's BlenderBot", "size": "400MB", "type": "Conversational"},
                "microsoft/Phi-3-mini-4k-instruct": {"description": "Microsoft's Phi-3 Mini", "size": "2.4GB", "type": "Instruction Following"},
                "google/flan-t5-large": {"description": "Google's FLAN-T5", "size": "780MB", "type": "Text Generation"}
            }
        }
        
        return model_info.get(provider, {}).get(model, {
            "description": "Model information not available",
            "size": "Unknown",
            "type": "General"
        })

# Create global instance
multi_model = MultiModelHelper()
