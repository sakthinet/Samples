import { CheckCircle, XCircle, Clock, AlertCircle, Play, Pause } from 'lucide-react';

export const getStatusIcon = (state) => {
  const iconProps = { className: "w-4 h-4" };
  
  switch (state) {
    case 'success':
      return <CheckCircle {...iconProps} className="w-4 h-4 text-green-500" />;
    case 'failed':
      return <XCircle {...iconProps} className="w-4 h-4 text-red-500" />;
    case 'running':
      return <Clock {...iconProps} className="w-4 h-4 text-blue-500 animate-spin" />;
    default:
      return <AlertCircle {...iconProps} className="w-4 h-4 text-gray-500" />;
  }
};

export const getStatusColor = (state) => {
  switch (state) {
    case 'success':
      return 'bg-green-100 text-green-800';
    case 'failed':
      return 'bg-red-100 text-red-800';
    case 'running':
      return 'bg-blue-100 text-blue-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export const getDagStatusIcon = (isActive, isPaused) => {
  if (isPaused) {
    return <Pause className="w-4 h-4 text-orange-500" />;
  }
  return <Play className="w-4 h-4 text-green-500" />;
};