import React, { useState, useEffect } from 'react';

const AirflowDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(false);
  const [dags, setDags] = useState([]);
  const [filteredDags, setFilteredDags] = useState([]);
  const [error, setError] = useState(null);
  const [lastRefresh, setLastRefresh] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('unknown');
  const [darkMode, setDarkMode] = useState(false);
  const [viewMode, setViewMode] = useState('cards');
  
  // Search and Filter States
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [tagFilter, setTagFilter] = useState('all');
  const [scheduleFilter, setScheduleFilter] = useState('all');
  
  // DAG Management States
  const [selectedDags, setSelectedDags] = useState(new Set());
  const [showBulkActions, setShowBulkActions] = useState(false);
  
  // Statistics
  const [statistics, setStatistics] = useState({});

  // Load theme preference
  useEffect(() => {
    const savedTheme = localStorage.getItem('airflow-dashboard-theme');
    if (savedTheme === 'dark') setDarkMode(true);
  }, []);

  // Apply theme
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('airflow-dashboard-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('airflow-dashboard-theme', 'light');
    }
  }, [darkMode]);

  // Filter DAGs based on search and filters
  useEffect(() => {
    let filtered = dags.filter(dag => {
      const matchesSearch = dag.dag_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           dag.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || 
                           (statusFilter === 'active' && dag.is_active && !dag.is_paused) ||
                           (statusFilter === 'paused' && dag.is_paused) ||
                           (statusFilter === 'inactive' && !dag.is_active);
      
      const matchesTag = tagFilter === 'all' || 
                        dag.tag_names.some(tag => tag.toLowerCase().includes(tagFilter.toLowerCase()));
      
      const matchesSchedule = scheduleFilter === 'all' || 
                             dag.schedule_interval_display.toLowerCase().includes(scheduleFilter.toLowerCase());
      
      return matchesSearch && matchesStatus && matchesTag && matchesSchedule;
    });
    
    setFilteredDags(filtered);
  }, [dags, searchTerm, statusFilter, tagFilter, scheduleFilter]);

  // Calculate statistics
  useEffect(() => {
    if (dags.length > 0) {
      const stats = calculateStatistics(dags);
      setStatistics(stats);
    }
  }, [dags]);

  const calculateStatistics = (dagsData) => {
    const total = dagsData.length;
    const active = dagsData.filter(dag => dag.is_active && !dag.is_paused).length;
    const paused = dagsData.filter(dag => dag.is_paused).length;
    const inactive = dagsData.filter(dag => !dag.is_active).length;
    
    // Schedule type breakdown
    const scheduleTypes = {};
    dagsData.forEach(dag => {
      const schedule = dag.schedule_interval_display;
      scheduleTypes[schedule] = (scheduleTypes[schedule] || 0) + 1;
    });
    
    // Tag analysis
    const allTags = [];
    dagsData.forEach(dag => {
      allTags.push(...dag.tag_names);
    });
    const uniqueTags = [...new Set(allTags)];
    const tagCounts = {};
    allTags.forEach(tag => {
      tagCounts[tag] = (tagCounts[tag] || 0) + 1;
    });
    
    // File location analysis
    const directories = {};
    dagsData.forEach(dag => {
      const dir = dag.fileloc.split('/').slice(0, -1).join('/');
      directories[dir] = (directories[dir] || 0) + 1;
    });
    
    return {
      total, active, paused, inactive,
      scheduleTypes,
      uniqueTags: uniqueTags.length,
      tagCounts,
      directories,
      avgMaxRuns: Math.round(dagsData.reduce((sum, dag) => sum + parseInt(dag.max_active_runs || 0), 0) / total)
    };
  };

  // Safe utility functions
  const safeString = (value) => {
    if (value === null || value === undefined) return 'N/A';
    if (typeof value === 'string') return value;
    if (typeof value === 'object' && value.value !== undefined) return String(value.value);
    if (typeof value === 'object' && value.__type !== undefined) return String(value.__type);
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  };

  const getScheduleInterval = (dag) => {
    if (!dag.schedule_interval) return 'None';
    if (typeof dag.schedule_interval === 'string') return dag.schedule_interval;
    if (typeof dag.schedule_interval === 'object') {
      if (dag.schedule_interval.__type) return dag.schedule_interval.__type;
      if (dag.schedule_interval.value) return dag.schedule_interval.value;
      return 'Complex Schedule';
    }
    return 'Unknown';
  };

  const getTagNames = (tags) => {
    if (!tags || !Array.isArray(tags)) return [];
    return tags.map(tag => {
      if (typeof tag === 'string') return tag;
      if (typeof tag === 'object' && tag.name) return tag.name;
      return 'Unknown Tag';
    });
  };

  const loadData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/v1/dags', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      let dagsArray = [];
      if (data.dags && Array.isArray(data.dags)) {
        dagsArray = data.dags;
      } else if (Array.isArray(data)) {
        dagsArray = data;
      }

      const processedDags = dagsArray.map(dag => ({
        ...dag,
        dag_id: safeString(dag.dag_id),
        description: safeString(dag.description || dag.timetable_description),
        schedule_interval_display: getScheduleInterval(dag),
        tag_names: getTagNames(dag.tags),
        fileloc: safeString(dag.fileloc),
        last_parsed_time: safeString(dag.last_parsed_time),
        max_active_runs: safeString(dag.max_active_runs),
        is_active: Boolean(dag.is_active),
        is_paused: Boolean(dag.is_paused)
      }));

      setDags(processedDags);
      setLastRefresh(new Date());
      setConnectionStatus('connected');
      setError(null);
      
    } catch (err) {
      setError(`Failed to load data: ${err.message}`);
      setConnectionStatus('disconnected');
      setDags([]);
    } finally {
      setLoading(false);
    }
  };

  // DAG Management Functions
  const pauseDag = async (dagId) => {
    try {
      const response = await fetch(`/api/v1/dags/${dagId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_paused: true })
      });
      
      if (response.ok) {
        setDags(prev => prev.map(dag => 
          dag.dag_id === dagId ? { ...dag, is_paused: true } : dag
        ));
      }
    } catch (err) {
      setError(`Failed to pause DAG: ${err.message}`);
    }
  };

  const unpauseDag = async (dagId) => {
    try {
      const response = await fetch(`/api/v1/dags/${dagId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_paused: false })
      });
      
      if (response.ok) {
        setDags(prev => prev.map(dag => 
          dag.dag_id === dagId ? { ...dag, is_paused: false } : dag
        ));
      }
    } catch (err) {
      setError(`Failed to unpause DAG: ${err.message}`);
    }
  };

  const triggerDag = async (dagId) => {
    try {
      const response = await fetch(`/api/v1/dags/${dagId}/dagRuns`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dag_run_id: `manual_${new Date().toISOString()}`,
          execution_date: new Date().toISOString()
        })
      });
      
      if (response.ok) {
        alert(`DAG ${dagId} triggered successfully!`);
      }
    } catch (err) {
      setError(`Failed to trigger DAG: ${err.message}`);
    }
  };

  const handleBulkAction = async (action) => {
    const dagIds = Array.from(selectedDags);
    
    for (const dagId of dagIds) {
      if (action === 'pause') await pauseDag(dagId);
      else if (action === 'unpause') await unpauseDag(dagId);
      else if (action === 'trigger') await triggerDag(dagId);
    }
    
    setSelectedDags(new Set());
    setShowBulkActions(false);
  };

  const toggleDagSelection = (dagId) => {
    const newSelected = new Set(selectedDags);
    if (newSelected.has(dagId)) {
      newSelected.delete(dagId);
    } else {
      newSelected.add(dagId);
    }
    setSelectedDags(newSelected);
    setShowBulkActions(newSelected.size > 0);
  };

  const formatDate = (dateString) => {
    if (!dateString || dateString === 'N/A') return 'N/A';
    try {
      return new Date(dateString).toLocaleString();
    } catch (error) {
      return 'Invalid Date';
    }
  };

  const getStatusColor = (isPaused, isActive) => {
    if (!isActive) return darkMode 
      ? 'bg-gray-800 text-gray-300 border-gray-600' 
      : 'bg-gray-100 text-gray-800 border-gray-200';
    if (isPaused) return darkMode 
      ? 'bg-orange-900 text-orange-300 border-orange-700' 
      : 'bg-orange-100 text-orange-800 border-orange-200';
    return darkMode 
      ? 'bg-green-900 text-green-300 border-green-700' 
      : 'bg-green-100 text-green-800 border-green-200';
  };

  const getStatusText = (isPaused, isActive) => {
    if (!isActive) return 'Inactive';
    if (isPaused) return 'Paused';
    return 'Active';
  };

  const getFileInfo = (fileloc) => {
    const parts = fileloc.split('/');
    const filename = parts[parts.length - 1];
    const directory = parts.slice(0, -1).join('/');
    return { filename, directory };
  };

  // Get unique values for filter dropdowns
  const getUniqueValues = () => {
    const tags = [...new Set(dags.flatMap(dag => dag.tag_names))];
    const schedules = [...new Set(dags.map(dag => dag.schedule_interval_display))];
    return { tags, schedules };
  };

  const { tags: uniqueTags, schedules: uniqueSchedules } = getUniqueValues();

  // Enhanced DAG Card Component
  const DagCard = ({ dag }) => {
    const fileInfo = getFileInfo(dag.fileloc);
    const isSelected = selectedDags.has(dag.dag_id);
    
    return (
      <div className={`rounded-xl border-2 transition-all duration-300 hover:shadow-xl hover:scale-105 ${
        isSelected ? 'ring-2 ring-blue-500' : ''
      } ${
        darkMode 
          ? 'bg-gray-800 border-gray-700 hover:border-gray-600' 
          : 'bg-white border-gray-200 hover:border-gray-300'
      }`}>
        <div className="p-6">
          {/* Header with Checkbox */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={isSelected}
                onChange={() => toggleDagSelection(dag.dag_id)}
                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
              />
              <div className={`w-2 h-8 rounded-full ${
                dag.is_active && !dag.is_paused ? 'bg-green-500' : 
                dag.is_paused ? 'bg-orange-500' : 'bg-gray-400'
              }`}></div>
              <div>
                <h3 className={`text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {dag.dag_id}
                </h3>
                <span className="text-2xl">
                  {dag.is_paused ? '⏸️' : dag.is_active ? '▶️' : '⏹️'}
                </span>
              </div>
            </div>
            <span className={`px-3 py-1 rounded-full text-xs font-bold border-2 ${getStatusColor(dag.is_paused, dag.is_active)}`}>
              {getStatusText(dag.is_paused, dag.is_active)}
            </span>
          </div>

          {/* Description */}
          <p className={`text-sm mb-4 line-clamp-2 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            {dag.description}
          </p>

          {/* File Information */}
          <div className={`mb-4 p-3 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
            <div className="text-xs">
              <div className={`font-semibold ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                📁 {fileInfo.filename}
              </div>
              <div className={`mt-1 text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'} truncate`}>
                {fileInfo.directory}
              </div>
            </div>
          </div>

          {/* Info Grid */}
          <div className="grid grid-cols-2 gap-4 text-sm mb-4">
            <div>
              <span className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Schedule:</span>
              <div className={`font-semibold mt-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {dag.schedule_interval_display}
              </div>
            </div>
            <div>
              <span className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Max Runs:</span>
              <div className={`font-semibold mt-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {dag.max_active_runs}
              </div>
            </div>
          </div>

          {/* Last Parsed */}
          <div className="text-xs mb-4">
            <span className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Last Parsed:</span>
            <div className={`mt-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              {formatDate(dag.last_parsed_time)}
            </div>
          </div>

          {/* Tags */}
          {dag.tag_names && dag.tag_names.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-4">
              {dag.tag_names.slice(0, 3).map((tagName, tagIndex) => (
                <span key={tagIndex} className={`text-xs px-2 py-1 rounded-full ${
                  darkMode 
                    ? 'bg-blue-900 text-blue-300 border border-blue-700' 
                    : 'bg-blue-100 text-blue-800 border border-blue-200'
                }`}>
                  {tagName}
                </span>
              ))}
              {dag.tag_names.length > 3 && (
                <span className={`text-xs px-2 py-1 rounded-full ${
                  darkMode 
                    ? 'bg-gray-700 text-gray-300' 
                    : 'bg-gray-100 text-gray-600'
                }`}>
                  +{dag.tag_names.length - 3}
                </span>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2">
            <button
              onClick={() => dag.is_paused ? unpauseDag(dag.dag_id) : pauseDag(dag.dag_id)}
              className={`flex-1 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                dag.is_paused 
                  ? 'bg-green-600 text-white hover:bg-green-700' 
                  : 'bg-orange-600 text-white hover:bg-orange-700'
              }`}
            >
              {dag.is_paused ? '▶️ Unpause' : '⏸️ Pause'}
            </button>
            <button
              onClick={() => triggerDag(dag.dag_id)}
              className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors"
            >
              🚀 Trigger
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      darkMode ? 'bg-gray-900' : 'bg-gray-50'
    }`}>
      <div className="w-full px-4 sm:px-6 lg:px-8 py-6">
        {/* Header */}
        <div className={`rounded-xl border-2 p-6 mb-6 ${
          darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
        }`}>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className={`text-4xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                Airflow DAGs Dashboard
              </h1>
              <p className={`mt-1 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                Monitor and manage your Apache Airflow DAGs
              </p>
            </div>
            <div className="mt-4 lg:mt-0 flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
              {/* Theme Toggle */}
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  darkMode ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <span className="text-lg">{darkMode ? '☀️' : '🌙'}</span>
                <span className="text-sm font-medium">{darkMode ? 'Light' : 'Dark'}</span>
              </button>

              {/* View Mode Toggle */}
              <div className={`flex rounded-lg p-1 ${darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
                <button
                  onClick={() => setViewMode('cards')}
                  className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                    viewMode === 'cards'
                      ? (darkMode ? 'bg-blue-600 text-white' : 'bg-blue-600 text-white')
                      : (darkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900')
                  }`}
                >
                  📇 Cards
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                    viewMode === 'list'
                      ? (darkMode ? 'bg-blue-600 text-white' : 'bg-blue-600 text-white')
                      : (darkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900')
                  }`}
                >
                  📋 List
                </button>
              </div>

              {/* Connection Status */}
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${
                  connectionStatus === 'connected' ? 'bg-green-500' : 
                  connectionStatus === 'disconnected' ? 'bg-red-500' : 'bg-yellow-500'
                }`}></div>
                <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  {connectionStatus === 'connected' ? 'Connected' : 'Disconnected'}
                </span>
              </div>

              {lastRefresh && (
                <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Last updated: {lastRefresh.toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className={`rounded-xl border-2 p-6 mb-6 ${
          darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
        }`}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Search */}
            <div className="lg:col-span-2">
              <input
                type="text"
                placeholder="Search DAGs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`w-full px-4 py-2 rounded-lg border ${
                  darkMode 
                    ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' 
                    : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                }`}
              />
            </div>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className={`px-4 py-2 rounded-lg border ${
                darkMode 
                  ? 'bg-gray-700 border-gray-600 text-white' 
                  : 'bg-white border-gray-300 text-gray-900'
              }`}
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="paused">Paused</option>
              <option value="inactive">Inactive</option>
            </select>

            {/* Tag Filter */}
            <select
              value={tagFilter}
              onChange={(e) => setTagFilter(e.target.value)}
              className={`px-4 py-2 rounded-lg border ${
                darkMode 
                  ? 'bg-gray-700 border-gray-600 text-white' 
                  : 'bg-white border-gray-300 text-gray-900'
              }`}
            >
              <option value="all">All Tags</option>
              {uniqueTags.map(tag => (
                <option key={tag} value={tag}>{tag}</option>
              ))}
            </select>

            {/* Schedule Filter */}
            <select
              value={scheduleFilter}
              onChange={(e) => setScheduleFilter(e.target.value)}
              className={`px-4 py-2 rounded-lg border ${
                darkMode 
                  ? 'bg-gray-700 border-gray-600 text-white' 
                  : 'bg-white border-gray-300 text-gray-900'
              }`}
            >
              <option value="all">All Schedules</option>
              {uniqueSchedules.map(schedule => (
                <option key={schedule} value={schedule}>{schedule}</option>
              ))}
            </select>
          </div>

          {/* Results Summary */}
          <div className="mt-4 flex items-center justify-between">
            <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Showing {filteredDags.length} of {dags.length} DAGs
              {searchTerm && ` for "${searchTerm}"`}
            </span>
            
            {/* Clear Filters */}
            {(searchTerm || statusFilter !== 'all' || tagFilter !== 'all' || scheduleFilter !== 'all') && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setStatusFilter('all');
                  setTagFilter('all');
                  setScheduleFilter('all');
                }}
                className="text-sm text-blue-600 hover:text-blue-800 font-medium"
              >
                Clear filters
              </button>
            )}
          </div>
        </div>

        {/* Bulk Actions */}
        {showBulkActions && (
          <div className={`rounded-xl border-2 p-4 mb-6 ${
            darkMode ? 'bg-blue-900 border-blue-700' : 'bg-blue-50 border-blue-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className={`font-medium ${darkMode ? 'text-blue-300' : 'text-blue-800'}`}>
                {selectedDags.size} DAGs selected
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => handleBulkAction('pause')}
                  className="px-4 py-2 bg-orange-600 text-white rounded-lg text-sm font-medium hover:bg-orange-700"
                >
                  ⏸️ Pause All
                </button>
                <button
                  onClick={() => handleBulkAction('unpause')}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"
                >
                  ▶️ Unpause All
                </button>
                <button
                  onClick={() => handleBulkAction('trigger')}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
                >
                  🚀 Trigger All
                </button>
                <button
                  onClick={() => {
                    setSelectedDags(new Set());
                    setShowBulkActions(false);
                  }}
                  className={`px-4 py-2 rounded-lg text-sm font-medium ${
                    darkMode 
                      ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' 
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Success Message */}
        {connectionStatus === 'connected' && dags.length > 0 && (
          <div className={`rounded-xl border-2 p-4 mb-6 ${
            darkMode ? 'bg-green-900 border-green-700' : 'bg-green-50 border-green-200'
          }`}>
            <div className="flex items-start">
              <span className="text-green-500 text-lg mr-3">✅</span>
              <div>
                <h3 className={`font-bold ${darkMode ? 'text-green-300' : 'text-green-800'}`}>
                  Successfully Connected!
                </h3>
                <p className={`mt-1 ${darkMode ? 'text-green-400' : 'text-green-700'}`}>
                  Loaded {dags.length} DAGs from Airflow API via proxy
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className={`rounded-xl border-2 p-4 mb-6 ${
            darkMode ? 'bg-red-900 border-red-700' : 'bg-red-50 border-red-200'
          }`}>
            <div className="flex items-start">
              <span className="text-red-500 text-lg mr-3">❌</span>
              <div className="flex-1">
                <h3 className={`font-bold ${darkMode ? 'text-red-300' : 'text-red-800'}`}>Error</h3>
                <p className={`mt-1 text-sm ${darkMode ? 'text-red-400' : 'text-red-700'}`}>{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Statistics Dashboard */}
        {Object.keys(statistics).length > 0 && (
          <div className={`rounded-xl border-2 p-6 mb-6 ${
            darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
          }`}>
            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              📊 Analytics & Statistics
            </h2>
            
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {[
                { title: 'Total DAGs', value: statistics.total, icon: '📊', color: 'blue' },
                { title: 'Active DAGs', value: statistics.active, icon: '▶️', color: 'green' },
                { title: 'Paused DAGs', value: statistics.paused, icon: '⏸️', color: 'orange' },
                { title: 'Avg Max Runs', value: statistics.avgMaxRuns, icon: '🔢', color: 'purple' }
              ].map((stat, index) => (
                <div key={index} className={`rounded-lg p-4 ${
                  darkMode 
                    ? `bg-${stat.color}-900 border border-${stat.color}-700` 
                    : `bg-${stat.color}-50 border border-${stat.color}-200`
                }`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className={`text-sm font-bold ${
                        darkMode ? `text-${stat.color}-300` : `text-${stat.color}-600`
                      }`}>
                        {stat.title}
                      </p>
                      <p className={`text-2xl font-bold ${
                        darkMode ? `text-${stat.color}-200` : `text-${stat.color}-900`
                      }`}>
                        {stat.value}
                      </p>
                    </div>
                    <span className="text-2xl">{stat.icon}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Schedule Distribution */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h3 className={`text-lg font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  Schedule Distribution
                </h3>
                <div className="space-y-2">
                  {Object.entries(statistics.scheduleTypes)
                    .sort(([,a], [,b]) => b - a)
                    .slice(0, 5)
                    .map(([schedule, count]) => (
                    <div key={schedule} className="flex items-center justify-between">
                      <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        {schedule}
                      </span>
                      <div className="flex items-center">
                        <div className={`w-20 h-2 rounded-full mr-2 ${darkMode ? 'bg-gray-700' : 'bg-gray-200'}`}>
                          <div 
                            className="h-2 bg-blue-500 rounded-full"
                            style={{ width: `${(count / statistics.total) * 100}%` }}
                          ></div>
                        </div>
                        <span className={`text-sm font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                          {count}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Top Tags */}
              <div>
                <h3 className={`text-lg font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  Top Tags ({statistics.uniqueTags} total)
                </h3>
                <div className="space-y-2">
                  {Object.entries(statistics.tagCounts)
                    .sort(([,a], [,b]) => b - a)
                    .slice(0, 5)
                    .map(([tag, count]) => (
                    <div key={tag} className="flex items-center justify-between">
                      <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        {tag}
                      </span>
                      <div className="flex items-center">
                        <div className={`w-20 h-2 rounded-full mr-2 ${darkMode ? 'bg-gray-700' : 'bg-gray-200'}`}>
                          <div 
                            className="h-2 bg-green-500 rounded-full"
                            style={{ width: `${(count / statistics.total) * 100}%` }}
                          ></div>
                        </div>
                        <span className={`text-sm font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                          {count}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Directory Distribution */}
            <div className="mt-6">
              <h3 className={`text-lg font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                File Directory Distribution
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(statistics.directories)
                  .sort(([,a], [,b]) => b - a)
                  .slice(0, 6)
                  .map(([dir, count]) => (
                  <div key={dir} className={`p-3 rounded-lg ${
                    darkMode ? 'bg-gray-700' : 'bg-gray-50'
                  }`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className={`text-xs font-mono truncate ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                          📁 {dir || '/'}
                        </p>
                      </div>
                      <span className={`ml-2 text-sm font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                        {count}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className={`rounded-xl border-2 p-6 mb-6 ${
          darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
        }`}>
          <div className="flex flex-wrap gap-4">
            <button
              onClick={loadData}
              disabled={loading}
              className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-medium shadow-lg hover:shadow-xl"
            >
              📊 {loading ? 'Loading...' : 'Load Data'}
            </button>
            
            <button
              onClick={() => setActiveTab('reports')}
              className={`flex items-center px-6 py-3 rounded-xl transition-all duration-200 font-medium shadow-lg hover:shadow-xl ${
                activeTab === 'reports'
                  ? 'bg-green-600 text-white hover:bg-green-700'
                  : (darkMode 
                    ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200')
              }`}
            >
              📈 Reports
            </button>
            
            <button
              onClick={() => loadData()}
              disabled={loading}
              className="flex items-center px-6 py-3 bg-orange-600 text-white rounded-xl hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 font-medium shadow-lg hover:shadow-xl"
            >
              🔄 Refresh
            </button>

            <button
              onClick={async () => {
                try {
                  const response = await fetch('/api/v1/dags', { method: 'HEAD' });
                  if (response.ok) {
                    setConnectionStatus('connected');
                    setError(null);
                    alert('Connection successful!');
                  }
                } catch (err) {
                  setError('Connection test failed');
                }
              }}
              className="flex items-center px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-all duration-200 font-medium shadow-lg hover:shadow-xl"
            >
              🔗 Test Connection
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className={`rounded-xl border-2 mb-6 overflow-hidden ${
          darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
        }`}>
          <div className={`border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-4 px-1 border-b-2 font-bold text-sm transition-colors ${
                  activeTab === 'overview'
                    ? 'border-blue-500 text-blue-600'
                    : (darkMode 
                      ? 'border-transparent text-gray-400 hover:text-gray-300' 
                      : 'border-transparent text-gray-500 hover:text-gray-700')
                }`}
              >
                Overview ({filteredDags.length}/{dags.length})
              </button>
              <button
                onClick={() => setActiveTab('reports')}
                className={`py-4 px-1 border-b-2 font-bold text-sm transition-colors ${
                  activeTab === 'reports'
                    ? 'border-blue-500 text-blue-600'
                    : (darkMode 
                      ? 'border-transparent text-gray-400 hover:text-gray-300' 
                      : 'border-transparent text-gray-500 hover:text-gray-700')
                }`}
              >
                Detailed Reports
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div>
                {loading ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                    <span className={`ml-3 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                      Loading DAGs via proxy...
                    </span>
                  </div>
                ) : filteredDags.length > 0 ? (
                  viewMode === 'cards' ? (
                    /* Card Grid Layout */
                    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                      {filteredDags.map((dag, index) => (
                        <DagCard key={dag.dag_id || index} dag={dag} />
                      ))}
                    </div>
                  ) : (
                    /* List Layout */
                    <div className="space-y-4">
                      {filteredDags.map((dag, index) => (
                        <div key={dag.dag_id || index} className={`rounded-xl border-2 p-6 transition-all duration-300 hover:shadow-lg ${
                          selectedDags.has(dag.dag_id) ? 'ring-2 ring-blue-500' : ''
                        } ${
                          darkMode 
                            ? 'bg-gray-800 border-gray-700 hover:border-gray-600' 
                            : 'bg-white border-gray-200 hover:border-gray-300'
                        }`}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <input
                                type="checkbox"
                                checked={selectedDags.has(dag.dag_id)}
                                onChange={() => toggleDagSelection(dag.dag_id)}
                                className="w-4 h-4 text-blue-600"
                              />
                              <div className={`w-2 h-12 rounded-full ${
                                dag.is_active && !dag.is_paused ? 'bg-green-500' : 
                                dag.is_paused ? 'bg-orange-500' : 'bg-gray-400'
                              }`}></div>
                              <div>
                                <h3 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                                  {dag.dag_id}
                                </h3>
                                <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                                  {dag.description}
                                </p>
                                <p className={`text-xs mt-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                  📁 {getFileInfo(dag.fileloc).filename}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-4">
                              <div className="text-right text-sm">
                                <div className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Schedule</div>
                                <div className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                                  {dag.schedule_interval_display}
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <button
                                  onClick={() => dag.is_paused ? unpauseDag(dag.dag_id) : pauseDag(dag.dag_id)}
                                  className={`px-3 py-1 rounded text-xs font-bold ${
                                    dag.is_paused 
                                      ? 'bg-green-600 text-white hover:bg-green-700' 
                                      : 'bg-orange-600 text-white hover:bg-orange-700'
                                  }`}
                                >
                                  {dag.is_paused ? '▶️' : '⏸️'}
                                </button>
                                <button
                                  onClick={() => triggerDag(dag.dag_id)}
                                  className="px-3 py-1 bg-blue-600 text-white rounded text-xs font-bold hover:bg-blue-700"
                                >
                                  🚀
                                </button>
                              </div>
                              <span className={`px-3 py-1 rounded-full text-sm font-bold border-2 ${getStatusColor(dag.is_paused, dag.is_active)}`}>
                                {getStatusText(dag.is_paused, dag.is_active)}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )
                ) : (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">🔍</div>
                    <h3 className={`font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                      {dags.length === 0 ? 'No DAGs found' : 'No DAGs match your filters'}
                    </h3>
                    <p className={`mb-4 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      {dags.length === 0 
                        ? 'Click "Load Data" to fetch DAGs from Airflow API' 
                        : 'Try adjusting your search terms or filters'}
                    </p>
                    {dags.length === 0 && (
                      <button
                        onClick={loadData}
                        className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 font-medium"
                      >
                        Load Data
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'reports' && (
              <div>
                <h2 className={`text-2xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  Detailed Reports & Analysis
                </h2>
                
                {dags.length > 0 && (
                  <div className="space-y-8">
                    {/* Advanced Statistics Table */}
                    <div>
                      <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                        DAG Details Table
                      </h3>
                      <div className={`rounded-lg border overflow-hidden ${
                        darkMode ? 'border-gray-700' : 'border-gray-200'
                      }`}>
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className={`${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                            <tr>
                              <th className={`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${
                                darkMode ? 'text-gray-300' : 'text-gray-500'
                              }`}>
                                DAG ID
                              </th>
                              <th className={`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${
                                darkMode ? 'text-gray-300' : 'text-gray-500'
                              }`}>
                                Status
                              </th>
                              <th className={`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${
                                darkMode ? 'text-gray-300' : 'text-gray-500'
                              }`}>
                                Schedule
                              </th>
                              <th className={`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${
                                darkMode ? 'text-gray-300' : 'text-gray-500'
                              }`}>
                                Max Runs
                              </th>
                              <th className={`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${
                                darkMode ? 'text-gray-300' : 'text-gray-500'
                              }`}>
                                File
                              </th>
                              <th className={`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${
                                darkMode ? 'text-gray-300' : 'text-gray-500'
                              }`}>
                                Tags
                              </th>
                            </tr>
                          </thead>
                          <tbody className={`divide-y ${
                            darkMode 
                              ? 'bg-gray-800 divide-gray-700' 
                              : 'bg-white divide-gray-200'
                          }`}>
                            {filteredDags.map((dag, index) => (
                              <tr key={dag.dag_id || index} className={`hover:${
                                darkMode ? 'bg-gray-700' : 'bg-gray-50'
                              }`}>
                                <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium ${
                                  darkMode ? 'text-white' : 'text-gray-900'
                                }`}>
                                  {dag.dag_id}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(dag.is_paused, dag.is_active)}`}>
                                    {getStatusText(dag.is_paused, dag.is_active)}
                                  </span>
                                </td>
                                <td className={`px-6 py-4 whitespace-nowrap text-sm ${
                                  darkMode ? 'text-gray-300' : 'text-gray-900'
                                }`}>
                                  {dag.schedule_interval_display}
                                </td>
                                <td className={`px-6 py-4 whitespace-nowrap text-sm ${
                                  darkMode ? 'text-gray-300' : 'text-gray-900'
                                }`}>
                                  {dag.max_active_runs}
                                </td>
                                <td className={`px-6 py-4 whitespace-nowrap text-sm ${
                                  darkMode ? 'text-gray-300' : 'text-gray-900'
                                }`}>
                                  <span className="font-mono text-xs">
                                    {getFileInfo(dag.fileloc).filename}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                  <div className="flex flex-wrap gap-1">
                                    {dag.tag_names.slice(0, 2).map((tag, tagIndex) => (
                                      <span key={tagIndex} className={`text-xs px-2 py-1 rounded ${
                                        darkMode 
                                          ? 'bg-blue-900 text-blue-300' 
                                          : 'bg-blue-100 text-blue-800'
                                      }`}>
                                        {tag}
                                      </span>
                                    ))}
                                    {dag.tag_names.length > 2 && (
                                      <span className={`text-xs px-2 py-1 rounded ${
                                        darkMode 
                                          ? 'bg-gray-700 text-gray-300' 
                                          : 'bg-gray-100 text-gray-600'
                                      }`}>
                                        +{dag.tag_names.length - 2}
                                      </span>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AirflowDashboard;
