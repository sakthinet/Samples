import React from 'react';
import AirflowDashboard from './AirflowDashboard';
import './App.css';

function App() {
  return (
    <div className="App">
      <AirflowDashboard />
    </div>
  );
}

export default App;