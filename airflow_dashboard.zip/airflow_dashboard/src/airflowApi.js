// src/airflowApi.js

const BASE_URL = '/api/v1';
const defaultHeaders = {
  'Content-Type': 'application/json',
  'Authorization': 'Basic ' + btoa('airflow:airflow'),
};
// Helper function to handle API responses
const handleResponse = async (response) => {
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`HTTP ${response.status}: ${errorText}`);
  }
  return response.json();
};

// Helper function to make API requests with proper headers
const makeRequest = async (url, options = {}) => {
  const defaultHeaders = {
    'Content-Type': 'application/json',
    // Add basic auth if your Airflow requires authentication
    // 'Authorization': 'Basic ' + btoa('username:password'),
  };

  const config = {
    method: 'GET',
    headers: { ...defaultHeaders, ...options.headers },
    ...options,
  };

  try {
    const response = await fetch(url, config);
    return await handleResponse(response);
  } catch (error) {
    console.error(`API Request failed for ${url}:`, error);
    throw error;
  }
};

// Fetch all DAGs
export const fetchDags = async () => {
  try {
    const data = await makeRequest(`${BASE_URL}/dags`);
    return data;
  } catch (error) {
    console.error('Error fetching DAGs:', error);
    throw new Error('Failed to fetch DAGs. Make sure Airflow is running and accessible.');
  }
};

// Fetch DAG details
export const fetchDagDetails = async (dagId) => {
  try {
    const data = await makeRequest(`${BASE_URL}/dags/${dagId}`);
    return data;
  } catch (error) {
    console.error(`Error fetching DAG details for ${dagId}:`, error);
    throw error;
  }
};

// Fetch DAG runs for a specific DAG
export const fetchDagRuns = async (dagId, limit = 10) => {
  try {
    const data = await makeRequest(`${BASE_URL}/dags/${dagId}/dagRuns?limit=${limit}&order_by=-execution_date`);
    return data;
  } catch (error) {
    console.error(`Error fetching DAG runs for ${dagId}:`, error);
    throw error;
  }
};

// Fetch all DAG runs (recent)
export const fetchAllDagRuns = async (limit = 50) => {
  try {
    const data = await makeRequest(`${BASE_URL}/dagRuns?limit=${limit}&order_by=-execution_date`);
    return data;
  } catch (error) {
    console.error('Error fetching all DAG runs:', error);
    throw error;
  }
};

// Pause a DAG
export const pauseDag = async (dagId) => {
  try {
    const data = await makeRequest(`${BASE_URL}/dags/${dagId}`, {
      method: 'PATCH',
      body: JSON.stringify({ is_paused: true })
    });
    return data;
  } catch (error) {
    console.error(`Error pausing DAG ${dagId}:`, error);
    throw error;
  }
};

// Unpause a DAG
export const unpauseDag = async (dagId) => {
  try {
    const data = await makeRequest(`${BASE_URL}/dags/${dagId}`, {
      method: 'PATCH',
      body: JSON.stringify({ is_paused: false })
    });
    return data;
  } catch (error) {
    console.error(`Error unpausing DAG ${dagId}:`, error);
    throw error;
  }
};

// Trigger a DAG run
export const triggerDagRun = async (dagId, conf = {}) => {
  try {
    const data = await makeRequest(`${BASE_URL}/dags/${dagId}/dagRuns`, {
      method: 'POST',
      body: JSON.stringify({
        conf: conf,
        dag_run_id: `manual_${new Date().toISOString()}`
      })
    });
    return data;
  } catch (error) {
    console.error(`Error triggering DAG run for ${dagId}:`, error);
    throw error;
  }
};

// Test connection to Airflow API
export const testConnection = async () => {
  try {
    const data = await makeRequest(`${BASE_URL}/health`);
    return data;
  } catch (error) {
    console.error('Error testing Airflow connection:', error);
    throw error;
  }
};

// Get Airflow version and config info
export const getAirflowInfo = async () => {
  try {
    const data = await makeRequest(`${BASE_URL}/version`);
    return data;
  } catch (error) {
    console.error('Error fetching Airflow info:', error);
    throw error;
  }
};